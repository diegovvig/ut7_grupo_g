import express from "express";
import 'dotenv/config';
import equipoRoutes from "./routes/Equipo.routes.mjs";
import jugadorRoutes from "./routes/Jugador.routes.mjs";

const app = express();

app.use(express.json());

app.use("/api/equipos", equipoRoutes);

app.use("/api/jugadores", jugadorRoutes);

app.use("/api/ligas", ligaRoutes);

app.listen(3000, () => {
  console.log("API REST escuchando en puerto 3000");
});
