import supabase from "../config/supabase.mjs";

export async function getAllEquipos() {
  const { data, error } = await supabase
    .from("Equipos")
    .select("*");

  if (error) throw error;
  return data;
}

export async function getEquipoById(id) {
  const { data, error } = await supabase
    .from("Equipos")
    .select("*")
    .eq("id", id)
    .single();

  if (error) throw error;
  return data;
}

export async function createEquipo(equipo) {
  const { data, error } = await supabase
    .from("Equipos")
    .insert([equipo])
    .select();

  if (error) throw error;
  return data[0];
}

export async function updateEquipo(id, equipo) {
  const { data, error } = await supabase
    .from("Equipos")
    .update(equipo)
    .eq("id", id)
    .select();

  if (error) throw error;
  return data[0];
}

export async function deleteEquipo(id) {
  const { error } = await supabase
    .from("Equipos")
    .delete()
    .eq("id", id);

  if (error) throw error;
  return true;
}

export async function getValorMercadoPorEquipo() {
  const { data, error } = await supabase
    .from("Jugadores")
    .select("equipo, valor_mercado");

  if (error) throw error;

  const resultado = {};
  data.forEach(j => {
    resultado[j.equipo] = (resultado[j.equipo] || 0) + j.valor_mercado;
  });

  return resultado;
}
