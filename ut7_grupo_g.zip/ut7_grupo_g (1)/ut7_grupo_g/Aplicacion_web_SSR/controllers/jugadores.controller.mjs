import fetch from 'node-fetch';

const API = process.env.API_URL;

export const listarJugadores = async (req, res) => {
  const response = await fetch(`${API}/jugadores`);
  const jugadores = await response.json();
  res.render('completes/jugadores', { jugadores });
};

export const crearJugador = async (req, res) => {
  await fetch(`${API}/jugadores`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req.body)
  });
  res.redirect('/jugadores');
};

export const borrarJugador = async (req, res) => {
  await fetch(`${API}/jugadores/${req.params.id}`, { method: 'DELETE' });
  res.redirect('/jugadores');
};
