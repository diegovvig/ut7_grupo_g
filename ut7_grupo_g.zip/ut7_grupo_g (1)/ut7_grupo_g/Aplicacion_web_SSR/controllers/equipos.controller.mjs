import fetch from 'node-fetch';

const API = process.env.API_URL;

export const listarEquipos = async (req, res) => {
  const response = await fetch(`${API}/equipos`);
  const equipos = await response.json();
  res.render('completes/equipos', { equipos });
};

export const crearEquipo = async (req, res) => {
  await fetch(`${API}/equipos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req.body)
  });
  res.redirect('/equipos');
};

export const borrarEquipo = async (req, res) => {
  await fetch(`${API}/equipos/${req.params.id}`, { method: 'DELETE' });
  res.redirect('/equipos');
};
