import fetch from 'node-fetch';

const API = process.env.API_URL;

export const listarLigas = async (req, res) => {
  const response = await fetch(`${API}/ligas`);
  const ligas = await response.json();
  res.render('completes/ligas', { ligas });
};

export const crearLiga = async (req, res) => {
  await fetch(`${API}/ligas`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req.body)
  });
  res.redirect('/ligas');
};

export const borrarLiga = async (req, res) => {
  await fetch(`${API}/ligas/${req.params.id}`, { method: 'DELETE' });
  res.redirect('/ligas');
};
