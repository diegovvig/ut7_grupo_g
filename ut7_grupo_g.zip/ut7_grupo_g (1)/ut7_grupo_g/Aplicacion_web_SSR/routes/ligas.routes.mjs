import { Router } from 'express';
import {
  listarLigas,
  crearLiga,
  borrarLiga
} from '../controllers/ligas.controller.js';

const router = Router();

router.get('/', listarLigas);
router.post('/crear', crearLiga);
router.post('/borrar/:id', borrarLiga);

export default router;
