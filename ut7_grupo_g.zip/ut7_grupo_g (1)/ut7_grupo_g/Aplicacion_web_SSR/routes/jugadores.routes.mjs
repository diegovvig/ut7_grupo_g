import { Router } from 'express';
import {
  listarJugadores,
  crearJugador,
  borrarJugador
} from '../controllers/jugadores.controller.js';

const router = Router();

router.get('/', listarJugadores);
router.post('/crear', crearJugador);
router.post('/borrar/:id', borrarJugador);

export default router;
