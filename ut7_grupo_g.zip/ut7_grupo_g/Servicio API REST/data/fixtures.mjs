/*
  data/fixtures.mjs
  - Conjuntos de datos de ejemplo (fixtures) usados como fallback en desarrollo
  - Contiene arrays de `Ligas`, `Equipos` y `Jugadores` que facilitan pruebas
  - Se utilizan cuando la tabla en Supabase está vacía o para poblado rápido
*/
export const Ligas = [
  { id: 1, nombre: 'LaLiga', pais: 'España', maximo_equipo_ganador: 5 },
  { id: 2, nombre: 'Premier League', pais: 'Inglaterra', maximo_equipo_ganador: 4 }
];

export const Equipos = [
  { id: 1, nombre: 'Real Madrid', presupuesto: 800000000, titulos: 35, estadio: 'Santiago Bernabéu', liga: 1 },
  { id: 2, nombre: 'FC Barcelona', presupuesto: 700000000, titulos: 30, estadio: 'Camp Nou', liga: 1 },
  { id: 3, nombre: 'Manchester City', presupuesto: 900000000, titulos: 7, estadio: 'Etihad Stadium', liga: 2 }
];

export const Jugadores = [
  { id: 1, nombre: 'Lionel Messi', nacionalidad: 'Argentina', posicion: 'Delantero', fecha_nacimiento: '1987-06-24', equipo: 2, valor_mercado: 50000000, partidos: 800, goles: 700, asistencias: 300 },
  { id: 2, nombre: 'Cristiano Ronaldo', nacionalidad: 'Portugal', posicion: 'Delantero', fecha_nacimiento: '1985-02-05', equipo: 1, valor_mercado: 45000000, partidos: 1000, goles: 800, asistencias: 200 },
  { id: 3, nombre: 'Kylian Mbappé', nacionalidad: 'Francia', posicion: 'Delantero', fecha_nacimiento: '1998-12-20', equipo: 1, valor_mercado: 180000000, partidos: 250, goles: 200, asistencias: 100 },
  { id: 4, nombre: 'Neymar Jr', nacionalidad: 'Brasil', posicion: 'Delantero', fecha_nacimiento: '1992-02-05', equipo: 2, valor_mercado: 90000000, partidos: 400, goles: 300, asistencias: 200 },
  { id: 5, nombre: 'Sergio Ramos', nacionalidad: 'España', posicion: 'Defensa', fecha_nacimiento: '1986-03-30', equipo: 1, valor_mercado: 10000000, partidos: 700, goles: 100, asistencias: 50 },
  { id: 6, nombre: 'Luka Modrić', nacionalidad: 'Croacia', posicion: 'Centrocampista', fecha_nacimiento: '1985-09-09', equipo: 1, valor_mercado: 10000000, partidos: 600, goles: 100, asistencias: 150 },
  { id: 7, nombre: 'Kevin De Bruyne', nacionalidad: 'Bélgica', posicion: 'Centrocampista', fecha_nacimiento: '1991-06-28', equipo: 3, valor_mercado: 100000000, partidos: 400, goles: 100, asistencias: 200 },
  { id: 8, nombre: 'Erling Haaland', nacionalidad: 'Noruega', posicion: 'Delantero', fecha_nacimiento: '2000-07-21', equipo: 3, valor_mercado: 150000000, partidos: 150, goles: 150, asistencias: 30 },
  { id: 9, nombre: 'Vinicius Jr', nacionalidad: 'Brasil', posicion: 'Delantero', fecha_nacimiento: '2000-07-12', equipo: 1, valor_mercado: 120000000, partidos: 200, goles: 80, asistencias: 60 },
  { id: 10, nombre: 'Pedri', nacionalidad: 'España', posicion: 'Centrocampista', fecha_nacimiento: '2002-11-25', equipo: 2, valor_mercado: 80000000, partidos: 100, goles: 20, asistencias: 30 }
];
