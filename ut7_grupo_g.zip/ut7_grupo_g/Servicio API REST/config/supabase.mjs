/*
  config/supabase.mjs
  - Inicializa y exporta el cliente Supabase para uso por los repositorios
  - Lee `SUPABASE_URL` y `SUPABASE_KEY` / `SUPABASE_SERVICE_ROLE_KEY` desde el entorno
  - Lanza error si no están definidas las variables necesarias (fallo temprano)
*/
import { createClient } from '@supabase/supabase-js';

// URL del proyecto Supabase
const supabaseUrl = process.env.SUPABASE_URL;
// Preferir la service role key en backend si está disponible
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY ?? process.env.SUPABASE_KEY;

// Comprobación temprana de configuración para evitar fallos silenciosos
if (!supabaseUrl || !supabaseKey) {
  throw new Error("Las variables de entorno SUPABASE_URL o SUPABASE_KEY/SUPABASE_SERVICE_ROLE_KEY no están definidas");
}

// Crear e exportar el cliente Supabase (usar service role solo en servidor)
const supabase = createClient(supabaseUrl, supabaseKey);

export default supabase;
