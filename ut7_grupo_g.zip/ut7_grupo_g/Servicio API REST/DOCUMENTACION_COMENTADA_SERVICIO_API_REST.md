# Documentación comentada - Servicio API REST

Comentarios bloque por bloque de los ficheros en `Servicio API REST`.

## `app.mjs`
- Bloque imports: importa `express`, carga variables con `dotenv/config` e importa las rutas y configuración de supabase.
- Bloque inicialización: crea `app = express()` y registra `app.use(express.json())` para parsear JSON.
- Bloque mounting de rutas API y web: monta rutas en dos prefijos distintos `/api/equipos` (API REST) y también `/equipos` (mismo router disponible para rutas sin prefijo), igual para `jugadores` y `ligas`.
- Bloque arranque: `app.listen(3000)` y mensaje en consola. (Nota: puerto fijado a 3000 en código).

## `config/supabase.mjs`
- Bloque imports: importa `createClient` desde `@supabase/supabase-js`.
- Bloque lectura de variables: `SUPABASE_URL` y `SUPABASE_SERVICE_ROLE_KEY` | `SUPABASE_KEY`.
- Bloque validación: lanza error si faltan variables de entorno necesarias.
- Bloque creación de cliente: `createClient(supabaseUrl, supabaseKey)` y export por defecto para usar en repositorios.

## `data/fixtures.mjs`
- Bloque datos estáticos: arrays `Ligas`, `Equipos`, `Jugadores` con objetos de ejemplo usados como fallback si la BD está vacía (útil en desarrollo).

## Modelos (`models/*.mjs`)
- `Equipo.model.mjs`: clase `Equipo` con constructor que normaliza campos (`id`, `nombre`, `liga`, `presupuesto`, `titulos`, `estadio`).
- `Jugador.model.mjs`: clase `Jugador` con campos típicos (id, nombre, nacionalidad, posicion, fecha_nacimiento, equipo, valor_mercado, partidos, goles, asistencias).
- `Liga.model.mjs`: clase `Liga` con (id, nombre, pais, maximo_equipo_ganador).

## Repositories (acceso a Supabase)
- `repositories/Equipo.repository.mjs`:
  - `getAllEquipos()`: `supabase.from('Equipos').select('*')` — devuelve lista de equipos.
  - `getEquipoById(id)`: `.eq('id', id).single()` — devuelve un equipo.
  - `createEquipo(equipo)`: `.insert([equipo]).select()` — inserta y devuelve el nuevo registro.
  - `updateEquipo(id, equipo)`: `.update(...).eq('id', id).select()` — actualiza y devuelve.
  - `deleteEquipo(id)`: `.delete().eq('id', id)` — borra equipo.
  - `getValorMercadoPorEquipo()`: obtiene `valor_mercado` de `Jugadores`, suma por `equipo`, obtiene nombres de `Equipos` y devuelve array `{ equipoId, nombre, valor_total }`.

- `repositories/Jugador.repository.mjs`:
  - Operaciones CRUD similares: `getAllJugadores`, `getJugadorById`, `createJugador`, `updateJugador`, `deleteJugador`.
  - Consultas auxiliares: `getTopGoleadores(limit)`, `getTopAsistencias(limit)` (ordena y limita), `getJugadoresPorEquipo(equipoId)`.

- `repositories/Liga.repository.mjs`:
  - `getAllLigas()`: intenta leer tabla `Ligas`; si BD vacía devuelve `fixtureLigas` (fallback).
  - `createLiga(liga)`: inserta liga.
  - `deleteLiga(id)`: borra liga.
  - `getEquiposPorLiga()`: cuenta equipos por campo `liga` y devuelve objeto `{ ligaId: cantidad, ... }`.

## Controllers (lógica y validaciones)
- `controllers/Equipo.controller.mjs`:
  - `getEquipos`: llama a `equipoRepo.getAllEquipos()` y devuelve JSON.
  - `getEquipo`: obtiene por id y devuelve, maneja 404 si no existe.
  - `createEquipo`: valida campos obligatorios (`nombre`, `liga`, `presupuesto`, `titulos`, `estadio`) y usa `supabase.from('Equipos').insert(...)` para crear, devuelve `201` con el nuevo objeto.
  - `updateEquipo`: actualiza campos de equipo por id usando `supabase.update(...).eq('id', ...)`.
  - `deleteEquipo`: usa `equipoRepo.deleteEquipo` y responde con mensaje.
  - `valorMercadoPorEquipo`: endpoint que llama al repo `getValorMercadoPorEquipo()` y devuelve los totales.
  - Nota: existe una función `validarEquipo` local con reglas básicas pero no se utiliza directamente para rechazar en los endpoints (validación manual se hace arriba).

- `controllers/Jugador.controller.mjs`:
  - `getJugadores`, `getJugador`: CRUD lectura con manejo de errores.
  - `createJugador`: valida presencia de todos los campos y crea jugador en `Jugadores` (usando `supabase.insert`).
  - `updateJugador`: actualiza por id con los campos indicados.
  - `deleteJugador`: delega a repo para borrar.
  - Funciones de estadísticas: `topGoleadores`, `topAsistencias` que llaman a los repos correspondientes.
  - `jugadoresPorEquipo`: valida que `equipoId` es número y consulta `supabase` por el campo `equipo`.

- `controllers/Liga.controller.mjs`:
  - `getLigas`: devuelve ligas usando `ligaRepo.getAllLigas()` (usa fixtures si BD vacía).
  - `createLiga`: valida `nombre`, `pais` y `maximo_equipo_ganador`, inserta y devuelve `201`.
  - `updateLiga`: similar a create, pero con `.update().eq('id', ...)`.
  - `deleteLiga`: elimina liga por id.
  - `equiposPorLiga`: devuelve conteo de equipos por liga a través del repo.

## Routes (endpoints)
- `routes/Equipo.routes.mjs`:
  - `GET /` -> `getEquipos`
  - `GET /:id` -> `getEquipo`
  - `POST /` -> `createEquipo`
  - `PUT /:id` -> `updateEquipo`
  - `DELETE /:id` -> `deleteEquipo`
  - `GET /stats/valor-mercado` -> `valorMercadoPorEquipo` (estadística por equipo).

- `routes/Jugador.routes.mjs`:
  - `GET /` -> `getJugadores`
  - `GET /:id` -> `getJugador`
  - `POST /` -> `createJugador`
  - `PUT /:id` -> `updateJugador`
  - `DELETE /:id` -> `deleteJugador`
  - `GET /stats/top-goleadores` -> `topGoleadores`
  - `GET /stats/top-asistencias` -> `topAsistencias`
  - `GET /equipo/:equipoId` -> `jugadoresPorEquipo`

- `routes/Liga.routes.mjs`:
  - `GET /` -> `getLigas`
  - `POST /` -> `createLiga`
  - `PUT /:id` -> `updateLiga`
  - `DELETE /:id` -> `deleteLiga`
  - `GET /stats/equipos-por-liga` -> `equiposPorLiga` (retorna conteo por liga)

## `package.json`
- Bloque `type: "module"` para usar módulos ES.
- Script `dev` ejecuta `node app.mjs`.
- Dependencias principales: `@supabase/supabase-js`, `dotenv`, `express`.

---

Notas finales y recomendaciones rápidas:
- `config/supabase.mjs` requiere definir `SUPABASE_URL` y `SUPABASE_KEY` (o `SUPABASE_SERVICE_ROLE_KEY`) en `.env` para que el servicio funcione.
- Algunos ficheros contienen comentarios o import paths con mayúsculas/minúsculas mezcladas (en Windows OK, en despliegues *nix podría dar problemas). Revisar consistencia de nombres (`Equipo.model.mjs` vs `equipo.model.mjs`).
- Puedo consolidar ambos documentos en `DOCUMENTACION_COMENTADA.md` en la raíz del proyecto si lo deseas.
