/*
  app.mjs - Servicio API REST
  - Inicializa la aplicación Express que expone los endpoints REST para
    `Equipos`, `Jugadores` y `Ligas`.
  - Monta rutas con prefijos `/api/*` y también las mismas rutas sin prefijo
    para permitir llamadas locales desde la app SSR.
  - No contiene lógica de negocio: delega en controllers y repositorios.
*/
import express from "express";
import 'dotenv/config';
import equipoRoutes from "./routes/Equipo.routes.mjs";
import jugadorRoutes from "./routes/Jugador.routes.mjs";
import ligaRoutes from "./routes/Liga.routes.mjs";
import supabase from "./config/supabase.mjs";

const app = express();

// Middleware para parsear JSON en el body de las peticiones
app.use(express.json());

// Montaje de routers: prefijo API y rutas idénticas sin prefijo (útil para SSR local)
console.log('Mounting routes');
app.use("/api/equipos", equipoRoutes);
app.use("/api/jugadores", jugadorRoutes);
app.use("/api/ligas", ligaRoutes);

// También exponer las mismas rutas sin el prefijo `/api` para llamadas internas
app.use("/equipos", equipoRoutes);
app.use("/jugadores", jugadorRoutes);
app.use("/ligas", ligaRoutes);
console.log('Routes mounted');

// Arranque del servidor en puerto fijo (3000)
app.listen(3000, () => {
  console.log("API REST escuchando en puerto 3000");
});
