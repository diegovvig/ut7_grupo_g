import express from "express";
import 'dotenv/config';
import equipoRoutes from "./routes/Equipo.routes.mjs";
import jugadorRoutes from "./routes/Jugador.routes.mjs";
import ligaRoutes from "./routes/Liga.routes.mjs";  // ← AÑADIR ESTA IMPORTACIÓN

const app = express();

app.use(express.json());

app.use("/api/equipos", equipoRoutes);
app.use("/api/jugadores", jugadorRoutes);
app.use("/api/ligas", ligaRoutes);

// Also mount without the /api prefix for compatibility with the SSR app
app.use("/equipos", equipoRoutes);
app.use("/jugadores", jugadorRoutes);
app.use("/ligas", ligaRoutes);

app.listen(3000, () => {
  console.log("API REST escuchando en puerto 3000");
});