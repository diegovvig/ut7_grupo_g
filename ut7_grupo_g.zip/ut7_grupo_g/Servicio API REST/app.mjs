import express from "express";
import equipoRoutes from "./routes/Equipo.routes.mjs";

const app = express();

app.use(express.json());

app.use("/api/equipos", equipoRoutes);

app.listen(3000, () => {
  console.log("API REST escuchando en puerto 3000");
});
