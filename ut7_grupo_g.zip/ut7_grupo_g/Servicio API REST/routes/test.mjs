import express from 'express';
import { testSupabase } from '../controllers/test.controller.js';

const router = express.Router();

router.get('/test-db', testSupabase);

export default router;
