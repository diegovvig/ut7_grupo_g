/*
  routes/Equipo.routes.mjs
  - Rutas REST para la entidad `Equipos`
  - Define endpoints CRUD y un endpoint estadístico para valor de mercado
*/
import express from "express";
import {
  getEquipos,
  getEquipo,
  createEquipo,
  updateEquipo,
  deleteEquipo,
  valorMercadoPorEquipo
} from "../controllers/Equipo.controller.mjs";

const router = express.Router();

// GET / -> listar equipos
router.get("/", getEquipos);

// GET /:id -> obtener equipo por id
router.get("/:id", getEquipo);

// POST / -> crear equipo
router.post("/", createEquipo);

// PUT /:id -> actualizar equipo
router.put("/:id", updateEquipo);

// DELETE /:id -> borrar equipo
router.delete("/:id", deleteEquipo);

// GET /stats/valor-mercado -> estadísticas: valor de mercado por equipo
router.get("/stats/valor-mercado", valorMercadoPorEquipo);

export default router;