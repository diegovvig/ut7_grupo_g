/*
  routes/Liga.routes.mjs
  - Rutas REST para manejar `Ligas` y obtener estadísticas relacionadas
*/
import express from "express";
import {
  getLigas,
  getLiga,
  createLiga,
  updateLiga,
  deleteLiga,
  equiposPorLiga
} from "../controllers/Liga.controller.mjs";

const router = express.Router();

// CRUD de ligas
console.log('Setting up liga routes');
router.get("/", getLigas);
router.get("/:id", getLiga);
console.log('Route /:id added');
router.post("/", createLiga);
router.put("/:id", updateLiga);
router.delete("/:id", deleteLiga);

// Estadística: número de equipos por liga
router.get("/stats/equipos-por-liga", equiposPorLiga);

export default router;