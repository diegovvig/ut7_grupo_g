import express from "express";
import {
  getLigas,
  createLiga,
  updateLiga,
  deleteLiga,
  equiposPorLiga
} from "../controllers/Liga.controller.mjs";

const router = express.Router();

router.get("/", getLigas);
router.post("/", createLiga);
router.put("/:id", updateLiga);
router.delete("/:id", deleteLiga);
router.get("/stats/equipos-por-liga", equiposPorLiga);

export default router;