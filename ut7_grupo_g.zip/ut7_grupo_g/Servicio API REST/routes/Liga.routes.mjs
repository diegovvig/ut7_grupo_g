import express from "express";
import {
  getLigas,
  createLiga,
  deleteLiga,
  equiposPorLiga  // ← AÑADIR
} from "../controllers/Liga.controller.mjs";

const router = express.Router();

router.get("/", getLigas);
router.post("/", createLiga);
router.delete("/:id", deleteLiga);
router.get("/stats/equipos-por-liga", equiposPorLiga);

export default router;