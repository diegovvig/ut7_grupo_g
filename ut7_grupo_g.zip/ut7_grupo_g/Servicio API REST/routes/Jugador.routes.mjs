/*
  routes/Jugador.routes.mjs
  - Endpoints REST para `Jugadores` incluyendo consultas estadísticas
*/
import express from "express";
import {
  getJugadores,
  getJugador,
  createJugador,
  updateJugador,
  deleteJugador,
  topGoleadores,
  topAsistencias,
  jugadoresPorEquipo
} from "../controllers/Jugador.controller.mjs";

const router = express.Router();

// CRUD básico
router.get("/", getJugadores);
router.get("/:id", getJugador);
router.post("/", createJugador);
router.put("/:id", updateJugador);
router.delete("/:id", deleteJugador);

// Estadísticas y consultas auxiliares
router.get("/stats/top-goleadores", topGoleadores);
router.get("/stats/top-asistencias", topAsistencias);
router.get("/equipo/:equipoId", jugadoresPorEquipo);

export default router;