/*
  models/Liga.model.mjs
  - Clase que modela la entidad `Liga` con campos básicos
  - Útil para documentación interna y normalización de objetos
*/
export default class Liga {
  constructor({ id, nombre, pais, maximo_equipo_ganador }) {
    this.id = id;
    this.nombre = nombre;
    this.pais = pais;
    this.maximo_equipo_ganador = maximo_equipo_ganador;
  }
}
