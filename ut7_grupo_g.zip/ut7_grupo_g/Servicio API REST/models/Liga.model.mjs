export default class Liga {
  constructor({ id, nombre }) {
    this.id = id;
    this.nombre = nombre;
  }
}
