/*
  models/Equipo.model.mjs
  - Clase simple que representa la entidad `Equipo` en la aplicación
  - Se usa como DTO/estructura para normalizar datos cuando proceda
*/
export default class Equipo {
  constructor({ id, nombre, liga, presupuesto, titulos, estadio }) {
    // Asignación directa de campos esperados del modelo
    this.id = id;
    this.nombre = nombre;
    this.liga = liga;
    this.presupuesto = presupuesto;
    this.titulos = titulos;
    this.estadio = estadio;
  }
}
