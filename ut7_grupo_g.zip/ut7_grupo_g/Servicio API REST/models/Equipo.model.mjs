export default class Equipo {
  constructor({ id, nombre, liga, presupuesto, titulos, estadio }) {
    this.id = id;
    this.nombre = nombre;
    this.liga = liga;
    this.presupuesto = presupuesto;
    this.titulos = titulos;
    this.estadio = estadio;
  }
}
