export default class Jugador {
  constructor(
    id,
    nombre,
    nacionalidad,
    posicion,
    fecha_nacimiento,
    equipo,
    valor_mercado,
    partidos,
    goles,
    asistencias
  ) {
    this.id = id;
    this.nombre = nombre;
    this.nacionalidad = nacionalidad;
    this.posicion = posicion;
    this.fecha_nacimiento = fecha_nacimiento;
    this.equipo = equipo;
    this.valor_mercado = valor_mercado;
    this.partidos = partidos;
    this.goles = goles;
    this.asistencias = asistencias;
  }
}
