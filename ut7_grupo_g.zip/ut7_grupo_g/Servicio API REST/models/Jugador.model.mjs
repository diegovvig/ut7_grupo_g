/*
  models/Jugador.model.mjs
  - Representa un `Jugador` con campos comunes (nombre, posición, estadísticas)
  - Sirve como referencia de estructura y para normalizar datos al crear objetos
*/
export default class Jugador {
  constructor({ id, nombre, nacionalidad, posicion, fecha_nacimiento, equipo, valor_mercado, partidos, goles, asistencias }) {
    this.id = id;
    this.nombre = nombre;
    this.nacionalidad = nacionalidad;
    this.posicion = posicion;
    this.fecha_nacimiento = fecha_nacimiento;
    this.equipo = equipo; // id del equipo al que pertenece
    this.valor_mercado = valor_mercado;
    this.partidos = partidos;
    this.goles = goles;
    this.asistencias = asistencias;
  }
}
