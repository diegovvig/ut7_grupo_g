export default class Equipo {
  constructor(id, nombre) {
    this.id = id;
    this.nombre = nombre;
  }
}
