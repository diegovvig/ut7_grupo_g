import * as ligaRepo from "../repositories/Liga.repository.mjs";
import Liga from "../models/Liga.model.mjs";
import supabase from "../config/supabase.mjs";

export async function getLigas(req, res) {
  try {
    const ligas = await ligaRepo.getAllLigas();
    res.json(ligas);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function createLiga(req, res) {
  try {
    const { nombre, pais, maximo_equipo_ganador } = req.body;

    if (!nombre || !pais || !maximo_equipo_ganador) {
      return res.status(400).json({
        error: "nombre, pais y maximo_equipo_ganador son obligatorios"
      });
    }

    const { data, error } = await supabase
      .from("Ligas")
      .insert([
        { nombre, pais, maximo_equipo_ganador }
      ])
      .select();

    if (error) throw error;

    res.status(201).json(data[0]);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

export async function updateLiga(req, res) {
  try {
    const { nombre, pais, maximo_equipo_ganador } = req.body;

    if (!nombre || !pais || !maximo_equipo_ganador) {
      return res.status(400).json({
        error: "nombre, pais y maximo_equipo_ganador son obligatorios"
      });
    }

    const { data, error } = await supabase
      .from("Ligas")
      .update({
        nombre,
        pais,
        maximo_equipo_ganador
      })
      .eq("id", req.params.id)
      .select();

    if (error) throw error;

    res.json(data[0]);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

export async function deleteLiga(req, res) {
  try {
    await ligaRepo.deleteLiga(req.params.id);
    res.json({ message: "Liga eliminada" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

function validarLiga(liga) {
  if (!liga.nombre || liga.nombre.trim() === "") {
    throw new Error("El nombre es obligatorio");
  }
}

export async function equiposPorLiga(req, res) {
  try {
    const data = await ligaRepo.getEquiposPorLiga();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
