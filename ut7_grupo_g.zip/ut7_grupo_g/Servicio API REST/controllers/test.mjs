import { getAllEquipos } from '../repositories/Equipo.repository.js';

export async function testSupabase(req, res) {
  try {
    const equipos = await getAllEquipos();
    res.json(equipos);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
