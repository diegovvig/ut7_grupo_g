/*
  controllers/Jugador.controller.mjs
  - Controlador REST que expone endpoints CRUD y consultas estadísticas para `Jugadores`
  - Valida entradas mínimas y delega en repositorios / Supabase para persistencia
*/
import * as jugadorRepo from "../repositories/Jugador.repository.mjs";
import * as equipoRepo from "../repositories/Equipo.repository.mjs";
import Jugador from "../models/jugador.model.mjs";
import supabase from "../config/supabase.mjs";

// GET /jugadores -> listar todos los jugadores
export async function getJugadores(req, res) {
  try {
    const jugadores = await jugadorRepo.getAllJugadores();
    res.json(jugadores);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// GET /jugadores/:id -> obtener un jugador por id
export async function getJugador(req, res) {
  try {
    const jugador = await jugadorRepo.getJugadorById(req.params.id);
    res.json(jugador);
  } catch (err) {
    res.status(404).json({ error: "Jugador no encontrado" });
  }
}

/*
  POST /jugadores
  - Valida campos obligatorios y crea el jugador en la tabla `Jugadores`
*/
export async function createJugador(req, res) {
  try {
    const {
      nombre,
      nacionalidad,
      posicion,
      fecha_nacimiento,
      equipo,
      valor_mercado,
      partidos,
      goles,
      asistencias
    } = req.body;

    if (
      !nombre || !nacionalidad || !posicion ||
      !fecha_nacimiento || !equipo ||
      valor_mercado == null || partidos == null ||
      goles == null || asistencias == null
    ) {
      return res.status(400).json({
        error: "Todos los campos son obligatorios"
      });
    }

    const { data, error } = await supabase
      .from("Jugadores")
      .insert([
        {
          nombre,
          nacionalidad,
          posicion,
          fecha_nacimiento,
          equipo,
          valor_mercado,
          partidos,
          goles,
          asistencias
        }
      ])
      .select();

    if (error) throw error;

    res.status(201).json(data[0]);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

/*
  PUT /jugadores/:id
  - Actualiza los campos del jugador indicado por id
*/
export async function updateJugador(req, res) {
  try {
    const {
      nombre,
      nacionalidad,
      posicion,
      fecha_nacimiento,
      equipo,
      valor_mercado,
      partidos,
      goles,
      asistencias
    } = req.body;

    const { data, error } = await supabase
      .from("Jugadores")
      .update({
        nombre,
        nacionalidad,
        posicion,
        fecha_nacimiento,
        equipo,
        valor_mercado,
        partidos,
        goles,
        asistencias
      })
      .eq("id", req.params.id)
      .select();

    if (error) throw error;

    res.json(data[0]);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

// DELETE /jugadores/:id -> elimina un jugador
export async function deleteJugador(req, res) {
  try {
    await jugadorRepo.deleteJugador(req.params.id);
    res.json({ message: "Jugador eliminado correctamente" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

// Validaciones internas (no usadas por los endpoints actuales)
function validarJugador(jugador) {
  if (!jugador.nombre || jugador.nombre.trim() === "") {
    throw new Error("El nombre es obligatorio");
  }
  if (jugador.goles < 0 || jugador.asistencias < 0) {
    throw new Error("Goles y asistencias no pueden ser negativos");
  }
}

// GET /stats/top-goleadores -> devuelve los máximos goleadores
export async function topGoleadores(req, res) {
  try {
    const data = await jugadorRepo.getTopGoleadores();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// GET /stats/top-asistencias -> devuelve los máximos asistentes
export async function topAsistencias(req, res) {
  try {
    const data = await jugadorRepo.getTopAsistencias();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

/*
  GET /equipo/:equipoId -> devuelve todos los jugadores de un equipo
  - Valida que `equipoId` sea numérico y consulta la tabla `Jugadores`
*/
export async function jugadoresPorEquipo(req, res) {
  try {
    const equipoId = Number(req.params.equipoId);

    if (isNaN(equipoId)) {
      return res.status(400).json({
        error: "El id de equipo debe ser un número"
      });
    }

    const { data, error } = await supabase
      .from("Jugadores")
      .select("*")
      .eq("equipo", equipoId);

    if (error) throw error;

    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
