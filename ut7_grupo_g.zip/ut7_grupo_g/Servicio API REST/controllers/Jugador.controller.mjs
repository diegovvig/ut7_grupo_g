import * as jugadorRepo from "../repositories/Jugador.repository.mjs";
import Jugador from "../models/jugador.model.mjs";

export async function getJugadores(req, res) {
  try {
    const jugadores = await jugadorRepo.getAllJugadores();
    res.json(jugadores);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function getJugador(req, res) {
  try {
    const jugador = await jugadorRepo.getJugadorById(req.params.id);
    res.json(jugador);
  } catch (err) {
    res.status(404).json({ error: "Jugador no encontrado" });
  }
}

export async function createJugador(req, res) {
  try {
    const jugador = new Jugador(req.body);
    const nuevoJugador = await jugadorRepo.createJugador(jugador);
    res.status(201).json(nuevoJugador);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

export async function updateJugador(req, res) {
  try {
    const jugador = new Jugador(req.body);
    const actualizado = await jugadorRepo.updateJugador(
      req.params.id,
      jugador
    );
    res.json(actualizado);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

export async function deleteJugador(req, res) {
  try {
    await jugadorRepo.deleteJugador(req.params.id);
    res.json({ message: "Jugador eliminado correctamente" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}
