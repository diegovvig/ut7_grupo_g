/*
  controllers/Equipo.controller.mjs
  - Controlador REST para la entidad `Equipo`
  - Valida entradas mínimas y usa tanto el repo como llamadas directas a Supabase
*/
import * as equipoRepo from "../repositories/Equipo.repository.mjs";
import Equipo from "../models/equipo.model.mjs";
import supabase from "../config/supabase.mjs";

// GET /equipos -> devuelve la lista completa de equipos
export async function getEquipos(req, res) {
  try {
    const equipos = await equipoRepo.getAllEquipos();
    res.json(equipos);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// GET /equipos/:id -> devuelve un equipo por id (404 si no existe)
export async function getEquipo(req, res) {
  try {
    const equipo = await equipoRepo.getEquipoById(req.params.id);
    res.json(equipo);
  } catch (err) {
    res.status(404).json({ error: "Equipo no encontrado" });
  }
}

/*
  POST /equipos
  - Valida que los campos obligatorios estén presentes
  - Inserta el registro en Supabase y devuelve 201 con el objeto creado
*/
export async function createEquipo(req, res) {
  try {
    const {
      nombre,
      liga,
      presupuesto,
      titulos,
      estadio
    } = req.body;

    if (!nombre || !liga || presupuesto == null || titulos == null || !estadio) {
      return res.status(400).json({
        error: "Todos los campos son obligatorios"
      });
    }

    const { data, error } = await supabase
      .from("Equipos")
      .insert([
        {
          nombre,
          liga,
          presupuesto,
          titulos,
          estadio
        }
      ])
      .select();

    if (error) throw error;

    res.status(201).json(data[0]);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

/*
  PUT /equipos/:id
  - Actualiza los campos permitidos de un equipo existente
*/
export async function updateEquipo(req, res) {
  try {
    const {
      nombre,
      liga,
      presupuesto,
      titulos,
      estadio
    } = req.body;

    const { data, error } = await supabase
      .from("Equipos")
      .update({
        nombre,
        liga,
        presupuesto,
        titulos,
        estadio
      })
      .eq("id", req.params.id)
      .select();

    if (error) throw error;

    res.json(data[0]);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

// DELETE /equipos/:id -> elimina un equipo delegando en el repositorio
export async function deleteEquipo(req, res) {
  try {
    await equipoRepo.deleteEquipo(req.params.id);
    res.json({ message: "Equipo eliminado correctamente" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

// Funciones auxiliares de validación (no usadas directamente por los endpoints actuales)
function validarEquipo(equipo) {
  if (!equipo.nombre || equipo.nombre.trim() === "") {
    throw new Error("El nombre es obligatorio");
  }
  if (equipo.puntos < 0) {
    throw new Error("Los puntos no pueden ser negativos");
  }
}

// GET /stats/valor-mercado -> devuelve valor de mercado total por equipo
export async function valorMercadoPorEquipo(req, res) {
  try {
    const data = await equipoRepo.getValorMercadoPorEquipo();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
