import * as equipoRepo from "../repositories/Equipo.repository.mjs";
import Equipo from "../models/equipo.model.mjs";

export async function getEquipos(req, res) {
  try {
    const equipos = await equipoRepo.getAllEquipos();
    res.json(equipos);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function getEquipo(req, res) {
  try {
    const equipo = await equipoRepo.getEquipoById(req.params.id);
    res.json(equipo);
  } catch (err) {
    res.status(404).json({ error: "Equipo no encontrado" });
  }
}

export async function createEquipo(req, res) {
  try {
    const equipo = new Equipo(req.body);
    const nuevoEquipo = await equipoRepo.createEquipo(equipo);
    res.status(201).json(nuevoEquipo);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

export async function updateEquipo(req, res) {
  try {
    const equipo = new Equipo(req.body);
    const actualizado = await equipoRepo.updateEquipo(req.params.id, equipo);
    res.json(actualizado);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

export async function deleteEquipo(req, res) {
  try {
    await equipoRepo.deleteEquipo(req.params.id);
    res.json({ message: "Equipo eliminado correctamente" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}
