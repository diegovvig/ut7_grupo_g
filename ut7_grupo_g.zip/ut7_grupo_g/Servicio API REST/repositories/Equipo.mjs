import { supabase } from '../config/supabase.mjs';

export async function getAllEquipos() {
  const { data, error } = await supabase
    .from('equipos')
    .select('*');

  if (error) throw error;
  return data;
}
