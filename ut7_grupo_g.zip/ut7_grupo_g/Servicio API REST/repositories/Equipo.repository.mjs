/*
  repositories/Equipo.repository.mjs
  - Contiene funciones que encapsulan las operaciones CRUD sobre la tabla `Equipos`
  - Todas las funciones devuelven datos o lanzan el error para que lo gestione el controller
*/
import supabase from "../config/supabase.mjs";

// Obtener todos los equipos
export async function getAllEquipos() {
  const { data, error } = await supabase
    .from("Equipos")
    .select("*");

  if (error) throw error;
  return data;
}

// Obtener un equipo por id (single devuelve un único objeto o error)
export async function getEquipoById(id) {
  const { data, error } = await supabase
    .from("Equipos")
    .select("*")
    .eq("id", id)
    .single();

  if (error) throw error;
  return data;
}

// Crear un nuevo equipo y devolver el registro creado
export async function createEquipo(equipo) {
  const { data, error } = await supabase
    .from("Equipos")
    .insert([equipo])
    .select();

  if (error) throw error;
  return data[0];
}

// Actualizar un equipo por id y devolver el equipo actualizado
export async function updateEquipo(id, equipo) {
  const { data, error } = await supabase
    .from("Equipos")
    .update(equipo)
    .eq("id", id)
    .select();

  if (error) throw error;
  return data[0];
}

// Borrar equipo por id
export async function deleteEquipo(id) {
  const { error } = await supabase
    .from("Equipos")
    .delete()
    .eq("id", id);

  if (error) throw error;
  return true;
}

/*
  getValorMercadoPorEquipo()
  - Calcula el valor total de mercado por equipo sumando el campo `valor_mercado`
  - Paso 1: obtener los jugadores con su equipo y valor
  - Paso 2: sumar por equipo
  - Paso 3: obtener nombres de equipos para enriquecer el resultado
  - Devuelve array de objetos { equipoId, nombre, valor_total }
*/
export async function getValorMercadoPorEquipo() {
  const { data: jugadores, error: err1 } = await supabase
    .from("Jugadores")
    .select("equipo, valor_mercado");

  if (err1) throw err1;

  // Sumar valor_mercado por id de equipo
  const sumaPorEquipo = {};
  jugadores.forEach(j => {
    sumaPorEquipo[j.equipo] = (sumaPorEquipo[j.equipo] || 0) + (j.valor_mercado || 0);
  });

  // Obtener equipos para mapear id -> nombre
  const { data: equipos, error: err2 } = await supabase
    .from("Equipos")
    .select("id, nombre");

  if (err2) throw err2;

  const mapa = {};
  equipos.forEach(e => { mapa[e.id] = e.nombre; });

  // Construir array con la suma por equipo y el nombre si está disponible
  return Object.keys(sumaPorEquipo).map(id => ({
    equipoId: Number(id),
    nombre: mapa[id] || null,
    valor_total: sumaPorEquipo[id]
  }));
}
