import supabase from "../config/supabase.mjs";

export async function getAllEquipos() {
  const { data, error } = await supabase
    .from("Equipos")
    .select("*");

  if (error) throw error;
  return data;
}

export async function getEquipoById(id) {
  const { data, error } = await supabase
    .from("Equipos")
    .select("*")
    .eq("id", id)
    .single();

  if (error) throw error;
  return data;
}

export async function createEquipo(equipo) {
  const { data, error } = await supabase
    .from("Equipos")
    .insert([equipo])
    .select();

  if (error) throw error;
  return data[0];
}

export async function updateEquipo(id, equipo) {
  const { data, error } = await supabase
    .from("Equipos")
    .update(equipo)
    .eq("id", id)
    .select();

  if (error) throw error;
  return data[0];
}

export async function deleteEquipo(id) {
  const { error } = await supabase
    .from("Equipos")
    .delete()
    .eq("id", id);

  if (error) throw error;
  return true;
}

export async function getValorMercadoPorEquipo() {
  const { data: jugadores, error: err1 } = await supabase
    .from("Jugadores")
    .select("equipo, valor_mercado");

  if (err1) throw err1;

  // Sum by equipo id
  const sumaPorEquipo = {};
  jugadores.forEach(j => {
    sumaPorEquipo[j.equipo] = (sumaPorEquipo[j.equipo] || 0) + (j.valor_mercado || 0);
  });

  // Fetch equipos to map ids to names
  const { data: equipos, error: err2 } = await supabase
    .from("Equipos")
    .select("id, nombre");

  if (err2) throw err2;

  const mapa = {};
  equipos.forEach(e => { mapa[e.id] = e.nombre; });

  // Return array of { equipoId, nombre, valor_total }
  return Object.keys(sumaPorEquipo).map(id => ({
    equipoId: Number(id),
    nombre: mapa[id] || null,
    valor_total: sumaPorEquipo[id]
  }));
}
