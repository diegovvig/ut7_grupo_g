import supabase from "../config/supabase.mjs";
import { Ligas as fixtureLigas } from "../data/fixtures.mjs";

export async function getAllLigas() {
  const { data, error } = await supabase
    .from("Ligas")
    .select("*");
  console.log('DEBUG getAllLigas ->', { dataLength: Array.isArray(data) ? data.length : null, error: error ? error.message || error : null });
  if (error) throw error;
  // If Supabase returns empty array, fall back to fixtures so API shows sample data
  if (!data || (Array.isArray(data) && data.length === 0)) {
    return fixtureLigas;
  }
  return data;
}

export async function createLiga(liga) {
  const { data, error } = await supabase
    .from("Ligas")
    .insert([liga])
    .select();
  if (error) throw error;
  return data[0];
}

export async function deleteLiga(id) {
  const { error } = await supabase
    .from("Ligas")
    .delete()
    .eq("id", id);
  if (error) throw error;
}

export async function getEquiposPorLiga() {
  const { data, error } = await supabase
    .from("Equipos")
    .select("liga");

  if (error) throw error;

  const resultado = {};
  data.forEach(e => {
    resultado[e.liga] = (resultado[e.liga] || 0) + 1;
  });

  return resultado;
}

