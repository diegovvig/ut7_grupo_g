import supabase from "../config/supabase.mjs";

export async function getAllLigas() {
  const { data, error } = await supabase
    .from("Ligas")
    .select("*");
  if (error) throw error;
  return data;
}

export async function createLiga(liga) {
  const { data, error } = await supabase
    .from("Ligas")
    .insert([liga])
    .select();
  if (error) throw error;
  return data[0];
}

export async function deleteLiga(id) {
  const { error } = await supabase
    .from("Ligas")
    .delete()
    .eq("id", id);
  if (error) throw error;
}

export async function getEquiposPorLiga() {
  const { data, error } = await supabase
    .from("Equipos")
    .select("liga");

  if (error) throw error;

  const resultado = {};
  data.forEach(e => {
    resultado[e.liga] = (resultado[e.liga] || 0) + 1;
  });

  return resultado;
}

