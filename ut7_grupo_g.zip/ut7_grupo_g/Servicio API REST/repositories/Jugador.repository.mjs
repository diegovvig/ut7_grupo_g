/*
  repositories/Jugador.repository.mjs
  - Funciones CRUD y consultas especializadas sobre la tabla `Jugadores`
  - Los controllers llaman a estas funciones para desacoplar la lógica de acceso a datos
*/
import supabase from "../config/supabase.mjs";

// Obtener todos los jugadores
export async function getAllJugadores() {
  const { data, error } = await supabase
    .from("Jugadores")
    .select("*");

  if (error) throw error;
  return data;
}

// Obtener un jugador por id
export async function getJugadorById(id) {
  const { data, error } = await supabase
    .from("Jugadores")
    .select("*")
    .eq("id", id)
    .single();

  if (error) throw error;
  return data;
}

// Insertar nuevo jugador
export async function createJugador(jugador) {
  const { data, error } = await supabase
    .from("Jugadores")
    .insert([jugador])
    .select();

  if (error) throw error;
  return data[0];
}

// Actualizar jugador por id
export async function updateJugador(id, jugador) {
  const { data, error } = await supabase
    .from("Jugadores")
    .update(jugador)
    .eq("id", id)
    .select();

  if (error) throw error;
  return data[0];
}

// Borrar jugador por id
export async function deleteJugador(id) {
  const { error } = await supabase
    .from("Jugadores")
    .delete()
    .eq("id", id);

  if (error) throw error;
  return true;
}

// Consultas auxiliares: top goleadores y top asistencias
export async function getTopGoleadores(limit = 5) {
  const { data, error } = await supabase
    .from("Jugadores")
    .select("nombre, goles")
    .order("goles", { ascending: false })
    .limit(limit);

  if (error) throw error;
  return data;
}

export async function getTopAsistencias(limit = 5) {
  const { data, error } = await supabase
    .from("Jugadores")
    .select("nombre, asistencias")
    .order("asistencias", { ascending: false })
    .limit(limit);

  if (error) throw error;
  return data;
}

// Obtener jugadores de un equipo específico
export async function getJugadoresPorEquipo(equipoId) {
  const { data, error } = await supabase
    .from("Jugadores")
    .select("*")
    .eq("equipo", equipoId);

  if (error) throw error;
  return data;
}
