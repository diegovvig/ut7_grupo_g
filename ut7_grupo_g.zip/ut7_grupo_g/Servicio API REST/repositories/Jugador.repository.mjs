import supabase from "../config/supabase.mjs";

export async function getAllJugadores() {
  const { data, error } = await supabase
    .from("Jugadores")
    .select("*");

  if (error) throw error;
  return data;
}

export async function getJugadorById(id) {
  const { data, error } = await supabase
    .from("Jugadores")
    .select("*")
    .eq("id", id)
    .single();

  if (error) throw error;
  return data;
}

export async function createJugador(jugador) {
  const { data, error } = await supabase
    .from("Jugadores")
    .insert([jugador])
    .select();

  if (error) throw error;
  return data[0];
}

export async function updateJugador(id, jugador) {
  const { data, error } = await supabase
    .from("Jugadores")
    .update(jugador)
    .eq("id", id)
    .select();

  if (error) throw error;
  return data[0];
}

export async function deleteJugador(id) {
  const { error } = await supabase
    .from("Jugadores")
    .delete()
    .eq("id", id);

  if (error) throw error;
  return true;
}
