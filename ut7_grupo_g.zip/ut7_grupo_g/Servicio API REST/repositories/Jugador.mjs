import { supabase } from '../config/supabase.mjs';

export async function getJugadoresByEquipo(equipoId) {
  const { data, error } = await supabase
    .from('jugadores')
    .select('*')
    .eq('equipo', equipoId);

  if (error) throw error;
  return data;
}
