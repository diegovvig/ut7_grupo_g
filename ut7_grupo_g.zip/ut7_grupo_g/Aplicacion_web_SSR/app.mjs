/*
  app.mjs - servidor SSR
  - Configura Express con EJS como motor de vistas
  - Registra middlewares (body parsers, static)
  - Monta rutas SSR y el manejador de errores
*/
import express from 'express';
import session from 'express-session';
import dotenv from 'dotenv';

// Cargar variables de entorno al inicio
dotenv.config();

// Rutas y middlewares de la aplicación
import indexRoutes from './routes/index.routes.mjs';
import ligasRoutes from './routes/ligas.routes.mjs';
import equiposRoutes from './routes/equipos.routes.mjs';
import jugadoresRoutes from './routes/jugadores.routes.mjs';
import adivinaRoutes from './routes/adivina.routes.mjs';
import { errorHandler } from "./middlewares/error.middleware.mjs";
import { requireAuth } from "./middlewares/session.middleware.mjs";

const app = express();

// Configuración de la vista
app.set('view engine', 'ejs');
app.set('views', './views');

// Middlewares para parseo y recursos estáticos
app.use(express.urlencoded({ extended: true })); // parsea form-url-encoded
app.use(express.json()); // parsea JSON en body
app.use(express.static('public')) // sirve assets desde /public

// Configuración de sesiones
app.use(session({
  secret: process.env.SESSION_SECRET || 'default_secret',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } // cambiar a true en producción con HTTPS
}));

// Rutas de autenticación
app.get('/login', (req, res) => {
  if (req.session.user) {
    return res.redirect('/');
  }
  res.render('login', { error: null });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const admins = {
    'Admin1': '123456',
    'Admin2': '654321',
    'Admin3': '162534'
  };
  if (admins[username] === password) {
    req.session.user = username;
    return res.redirect('/');
  } else {
    return res.render('login', { error: 'Credenciales incorrectas' });
  }
});

app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

// Montaje de rutas SSR: cada router gestiona su sección
app.use('/', indexRoutes);
app.use('/ligas', requireAuth, ligasRoutes);
app.use('/equipos', requireAuth, equiposRoutes);
app.use('/jugadores', requireAuth, jugadoresRoutes);
app.use('/', adivinaRoutes);

// Arranque del servidor en el puerto indicado en .env
app.listen(process.env.PORT, () => {
  console.log(`SSR funcionando en http://localhost:${process.env.PORT}`);
});

// Middleware global de manejo de errores (debe ir al final)
app.use(errorHandler);
