import express from 'express';
import dotenv from 'dotenv';

import indexRoutes from './routes/index.routes.js';
import ligasRoutes from './routes/ligas.routes.js';
import equiposRoutes from './routes/equipos.routes.js';
import jugadoresRoutes from './routes/jugadores.routes.js';

dotenv.config();

const app = express();

// Configuración
app.set('view engine', 'ejs');
app.set('views', './views');

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));

// Rutas
app.use('/', indexRoutes);
app.use('/ligas', ligasRoutes);
app.use('/equipos', equiposRoutes);
app.use('/jugadores', jugadoresRoutes);

// Servidor
app.listen(process.env.PORT, () => {
  console.log(`SSR funcionando en http://localhost:${process.env.PORT}`);
});