import express from 'express';
import dotenv from 'dotenv';

// Load environment variables before importing routes/controllers
dotenv.config();

import indexRoutes from './routes/index.routes.mjs';
import ligasRoutes from './routes/ligas.routes.mjs';
import equiposRoutes from './routes/equipos.routes.mjs';
import jugadoresRoutes from './routes/jugadores.routes.mjs';
import { errorHandler } from "./middlewares/error.middleware.mjs";

const app = express();

// Configuración
app.set('view engine', 'ejs');
app.set('views', './views');

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));

// Rutas
app.use('/', indexRoutes);
app.use('/ligas', ligasRoutes);
app.use('/equipos', equiposRoutes);
app.use('/jugadores', jugadoresRoutes);

// Servidor
app.listen(process.env.PORT, () => {
  console.log(`SSR funcionando en http://localhost:${process.env.PORT}`);
});

app.use(errorHandler);
