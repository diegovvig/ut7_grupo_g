/*
  auth.middleware.mjs
  - Inicializa Firebase Admin SDK en el proceso (solo si no está ya inicializado)
  - Exporta `authenticate` que verifica tokens Bearer usando `admin.auth().verifyIdToken`
  - Añade `req.user` con la información del token si la verificación es correcta
*/
import admin from "firebase-admin";

// Inicializar Firebase Admin SOLO UNA VEZ en el ciclo de vida del proceso
// Esto evita errores al reiniciar o al importar el módulo múltiples veces
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert({
      // Las credenciales se leen desde variables de entorno
      projectId: process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      // La clave privada suele contener saltos de línea que se almacenan como \n
      privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, "\n")
    })
  });
}

/*
  authenticate(req, res, next)
  - Bloque: comprueba que exista el header `Authorization` con formato `Bearer <token>`
  - Bloque: extrae el token y lo valida con Firebase Admin
  - Bloque: en caso de éxito añade `req.user = decodedToken` y llama `next()`
  - Bloque: en caso de fallo responde 401 y mensaje genérico
*/
export const authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;

    // Validación básica del header Authorization
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({
        error: "No autenticado"
      });
    }

    // Extraer token y verificarlo con Firebase
    const token = authHeader.split(" ")[1];
    const decodedToken = await admin.auth().verifyIdToken(token);

    // Guardar información del usuario en la request para su uso posterior
    req.user = decodedToken;
    next();
  } catch (error) {
    // En caso de token inválido o expirado, responder con 401
    return res.status(401).json({
      error: "Token inválido o expirado"
    });
  }
};
