/*
  error.middleware.mjs
  - Manejador global de errores para la aplicación SSR
  - Debe ser registrado al final de la cadena de middlewares
  - Loggea el error en el servidor y responde con JSON sencillo
*/
export const errorHandler = (err, req, res, next) => {
  // Registro del error en consola (útil durante desarrollo)
  console.error(err);

  // Responder con código de error proporcionado o 500 por defecto
  res.status(err.status || 500).json({
    error: err.message || "Error interno del servidor"
  });
};
