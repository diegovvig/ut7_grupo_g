/*
  validation.middleware.mjs
  - Factory que devuelve un middleware para validar la presencia de campos en `req.body`
  - Uso: `validateBody(['nombre','pais'])` y se puede aplicar en routes antes del handler
*/
export const validateBody = (requiredFields = []) => {
  return (req, res, next) => {
    const errors = [];

    // Comprobar cada campo requerido: existencia y no vacío
    for (const field of requiredFields) {
      if (
        !req.body.hasOwnProperty(field) ||
        req.body[field] === null ||
        req.body[field] === ""
      ) {
        // Acumular mensajes legibles para devolver al cliente
        errors.push(`El campo '${field}' es obligatorio`);
      }
    }

    // Si hay errores, detener la petición y responder 400 con la lista
    if (errors.length > 0) {
      return res.status(400).json({
        errors
      });
    }

    // Si todo bien, continuar con el siguiente middleware/handler
    next();
  };
};
