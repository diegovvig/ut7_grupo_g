/*
  jugadores.routes.mjs
  - Rutas SSR para la sección de jugadores
  - Encamina las peticiones a los handlers que llaman a la API REST
*/
import { Router } from 'express';
import {
  listarJugadores,
  crearJugador,
  borrarJugador
} from '../controllers/jugadores.controller.mjs';

import {
  mostrarCrearJugador,
  mostrarEditarJugador,
  editarJugador
} from '../controllers/jugadores.controller.mjs';

const router = Router();

// Mostrar listado de jugadores
router.get('/', listarJugadores);

// GET /jugadores/crear -> mostrar formulario de creación
router.get('/crear', mostrarCrearJugador);

// Crear jugador (recibe formulario desde la vista y lo reenvía a la API)
router.post('/crear', crearJugador);

// GET /jugadores/editar/:id -> mostrar formulario de edición
router.get('/editar/:id', mostrarEditarJugador);

// POST /jugadores/editar/:id -> actualizar jugador
router.post('/editar/:id', editarJugador);

// Borrar jugador por id
router.post('/borrar/:id', borrarJugador);

export default router;
