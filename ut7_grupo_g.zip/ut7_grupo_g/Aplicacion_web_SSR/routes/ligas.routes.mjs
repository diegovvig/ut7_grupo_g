/*
  ligas.routes.mjs
  - Rutas SSR encargadas de listar, crear y borrar ligas
  - Cada ruta delega la lógica al controller correspondiente
*/
import { Router } from 'express';
import {
  listarLigas,
  mostrarCrearLiga,
  crearLiga,
  mostrarEditarLiga,
  editarLiga,
  borrarLiga
} from '../controllers/ligas.controller.mjs';

const router = Router();

// GET /ligas -> renderiza listado de ligas
router.get('/', listarLigas);

// GET /ligas/crear -> muestra formulario de creación
router.get('/crear', mostrarCrearLiga);

// POST /ligas/crear -> reenvía formulario de creación a la API
router.post('/crear', crearLiga);

// GET /ligas/editar/:id -> muestra formulario de edición
router.get('/editar/:id', mostrarEditarLiga);

// POST /ligas/editar/:id -> actualiza liga por id
router.post('/editar/:id', editarLiga);

// POST /ligas/borrar/:id -> borra liga por id
router.post('/borrar/:id', borrarLiga);

export default router;
