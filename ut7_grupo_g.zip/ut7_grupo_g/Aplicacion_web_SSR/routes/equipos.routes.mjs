/*
  equipos.routes.mjs
  - Define las rutas SSR relacionadas con la sección 'equipos'
  - Usa los handlers del controller SSR para renderizar vistas y procesar formularios
*/
import { Router } from 'express';
import {
  listarEquipos,
  mostrarCrearEquipo,
  crearEquipo,
  mostrarEditarEquipo,
  editarEquipo,
  borrarEquipo
} from '../controllers/equipos.controller.mjs';

const router = Router();

// GET /equipos -> Mostrar listado de equipos (renderiza `equipos.ejs`)
router.get('/', listarEquipos);

// GET /equipos/crear -> mostrar formulario de creación
router.get('/crear', mostrarCrearEquipo);

// POST /equipos/crear -> Crear un nuevo equipo (envía formulario a la API REST)
router.post('/crear', crearEquipo);

// GET /equipos/editar/:id -> mostrar formulario de edición
router.get('/editar/:id', mostrarEditarEquipo);

// POST /equipos/editar/:id -> actualizar equipo
router.post('/editar/:id', editarEquipo);

// POST /equipos/borrar/:id -> Borrar un equipo por id (form action desde la vista)
router.post('/borrar/:id', borrarEquipo);

export default router;
