import { Router } from 'express';
import {
  listarEquipos,
  crearEquipo,
  borrarEquipo
} from '../controllers/equipos.controller.mjs';

const router = Router();

router.get('/', listarEquipos);
router.post('/crear', crearEquipo);
router.post('/borrar/:id', borrarEquipo);

export default router;
