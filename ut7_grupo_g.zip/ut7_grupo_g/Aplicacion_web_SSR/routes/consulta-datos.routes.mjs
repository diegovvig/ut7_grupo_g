/*
  consulta-datos.routes.mjs
  - Rutas SSR para la navegación jerárquica de usuario (no logueado)
  - Accesibles sin autenticación
  - Ligas → Equipos → Jugadores
*/
import { Router } from 'express';
import {
  listarLigasConsulta,
  listarEquiposConsulta,
  listarJugadoresConsulta
} from '../controllers/consulta-datos.controller.mjs';

const router = Router();

// GET /consultar-datos/ligas -> renderiza listado de ligas en tarjetas
router.get('/ligas', listarLigasConsulta);

// GET /consultar-datos/ligas/:ligaId/equipos -> renderiza equipos de una liga
router.get('/ligas/:ligaId/equipos', listarEquiposConsulta);

// GET /consultar-datos/ligas/:ligaId/equipos/:equipoId/jugadores -> renderiza jugadores de un equipo
router.get('/ligas/:ligaId/equipos/:equipoId/jugadores', listarJugadoresConsulta);

export default router;

