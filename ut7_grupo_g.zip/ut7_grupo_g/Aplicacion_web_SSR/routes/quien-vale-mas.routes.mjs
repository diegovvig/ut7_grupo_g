/*
  quien-vale-mas.routes.mjs
  - Router para las rutas del juego ¿Quién vale más?
*/
import { Router } from 'express';
import { mostrarJuego, jugar } from '../controllers/quien-vale-mas.controller.mjs';

const router = Router();

// Ruta para mostrar la página del juego
router.get('/quien-vale-mas', mostrarJuego);

// Ruta para iniciar el juego
router.post('/quien-vale-mas/jugar', jugar);

export default router;