/*
  adivina.routes.mjs
  - Router para las rutas del juego de adivinar el jugador
*/
import { Router } from 'express';
import { mostrarAdivinanza, buscarJugadores, intentarAdivinar, reiniciarJuego } from '../controllers/adivina.controller.mjs';

const router = Router();

// Ruta para mostrar la página de adivinanza
router.get('/adivina-jugador', mostrarAdivinanza);

// Ruta AJAX para buscar jugadores
router.get('/api/buscar-jugadores', buscarJugadores);

// Ruta para procesar un intento
router.post('/adivina-jugador/intento', intentarAdivinar);

// Ruta para reiniciar el juego
router.post('/adivina-jugador/reiniciar', reiniciarJuego);

export default router;