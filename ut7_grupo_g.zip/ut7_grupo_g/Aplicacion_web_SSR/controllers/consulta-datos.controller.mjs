/*
  consulta-datos.controller.mjs
  - Controlador para las vistas jerárquicas de usuario (no logueado)
  - Ligas → Equipos → Jugadores en formato de tarjetas
  - Renderizado SSR obteniendo datos de la API REST
*/
import fetch from 'node-fetch';

// URL base de la API REST
const API = process.env.API_URL ?? 'http://localhost:3000';

/*
  listarLigasConsulta(req, res)
  - Obtiene todas las ligas de la API
  - Renderiza vista de tarjetas para consulta de usuario
*/
export const listarLigasConsulta = async (req, res) => {
  try {
    const response = await fetch(`${API}/ligas`);
    const ligas = await response.json();

    res.render('consulta-ligas', {
      ligas,
      user: req.session.user
    });
  } catch (error) {
    console.error('Error al obtener ligas:', error);
    res.render('consulta-ligas', {
      ligas: [],
      error: 'No se pudieron cargar las ligas',
      user: req.session.user
    });
  }
};

/*
  listarEquiposConsulta(req, res)
  - Obtiene equipos de una liga específica
  - Renderiza vista de tarjetas de equipos con botón de volver
*/
export const listarEquiposConsulta = async (req, res) => {
  try {
    const ligaId = req.params.ligaId;

    // Obtener detalles de la liga
    const ligaResponse = await fetch(`${API}/ligas/${ligaId}`);
    const liga = await ligaResponse.json();

    // Obtener equipos de la liga
    const equiposResponse = await fetch(`${API}/equipos?liga_id=${ligaId}`);
    const equipos = await equiposResponse.json();

    // Obtener valor de mercado por equipo
    const valorResponse = await fetch(`${API}/equipos/stats/valor-mercado`);
    const valorPorEquipo = await valorResponse.json();

    console.log('Respuesta bruta valor-mercado:', JSON.stringify(valorPorEquipo, null, 2));

    // Crear un mapa de equipoId -> valorMercado para acceso rápido
    const mapValor = {};
    if (Array.isArray(valorPorEquipo)) {
      valorPorEquipo.forEach(item => {
        console.log('Item:', item);
        mapValor[item.equipoId] = item.valor_total;
      });
    }

    console.log('Mapa valor:', JSON.stringify(mapValor, null, 2));

    // Agregar valor de mercado a cada equipo
    const equiposConValor = equipos.map(equipo => ({
      ...equipo,
      valorMercado: mapValor[equipo.id] || 0
    }));

    console.log('Equipos con valor:', JSON.stringify(equiposConValor, null, 2));

    res.render('consulta-equipos', {
      liga,
      ligaId,
      equipos: equiposConValor,
      user: req.session.user
    });
  } catch (error) {
    console.error('Error al obtener equipos:', error);
    res.render('consulta-equipos', {
      liga: {},
      ligaId: req.params.ligaId,
      equipos: [],
      error: 'No se pudieron cargar los equipos',
      user: req.session.user
    });
  }
};

/*
  listarJugadoresConsulta(req, res)
  - Obtiene jugadores de un equipo específico
  - Renderiza vista de tarjetas de jugadores con botón de volver
*/
export const listarJugadoresConsulta = async (req, res) => {
  try {
    const { ligaId, equipoId } = req.params;

    // Obtener detalles del equipo
    const equipoResponse = await fetch(`${API}/equipos/${equipoId}`);
    const equipo = await equipoResponse.json();

    // Obtener jugadores del equipo - usar ruta correcta /equipo/:equipoId
    const jugadoresResponse = await fetch(`${API}/jugadores/equipo/${equipoId}`);
    const jugadores = await jugadoresResponse.json();

    // Obtener detalles de la liga para breadcrumb
    const ligaResponse = await fetch(`${API}/ligas/${ligaId}`);
    const liga = await ligaResponse.json();

    res.render('consulta-jugadores', {
      liga,
      ligaId,
      equipo,
      equipoId,
      jugadores,
      user: req.session.user
    });
  } catch (error) {
    console.error('Error al obtener jugadores:', error);
    res.render('consulta-jugadores', {
      liga: {},
      ligaId: req.params.ligaId,
      equipo: {},
      equipoId: req.params.equipoId,
      jugadores: [],
      error: 'No se pudieron cargar los jugadores',
      user: req.session.user
    });
  }
};
