/*
  quien-vale-mas.controller.mjs
  - Controlador para el juego ¿Quién vale más?
*/
import fetch from 'node-fetch';

/**
 * Muestra la vista del juego ¿Quién vale más?
 */
export const mostrarJuego = (req, res) => {
  res.render('quien_vale_mas', { user: req.session.user });
};

export const jugar = async (req, res) => {
  const dificultad = req.body.dificultad;
  console.log('=== JUGAR CONTROLLER STARTED ===');
  console.log('Dificultad:', dificultad);
  try {
    console.log('About to fetch from API...');
    const response = await fetch('http://localhost:3000/jugadores');
    console.log('Fetch completed, status:', response.status);
    
    if (!response.ok) {
      console.error('API response not ok:', response.status, response.statusText);
      throw new Error(`API responded with status ${response.status}`);
    }
    
    const allPlayers = await response.json();
    console.log('Players parsed successfully, count:', allPlayers ? allPlayers.length : 'null');
    
    if (!allPlayers || allPlayers.length === 0) {
      console.error('No players received from API');
      throw new Error('No players received');
    }
    
    // Seleccionar dos jugadores aleatorios
    const shuffled = [...allPlayers].sort(() => 0.5 - Math.random());
    const player1 = shuffled[0];
    const player2 = shuffled[1];
    console.log('Selected players:', player1?.nombre, 'and', player2?.nombre);
    
    // Crear lista ordenada de 51 jugadores para el juego
    const gamePlayers = allPlayers.slice(0, 51);
    console.log('Game players created, length:', gamePlayers.length);
    
    console.log('About to render view...');
    res.render('jugar_quien_vale_mas', { 
      user: req.session.user, 
      player1, 
      player2, 
      dificultad
    });
    console.log('=== VIEW RENDERED SUCCESSFULLY ===');
  } catch (error) {
    console.error('=== ERROR IN JUGAR CONTROLLER ===');
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
    
    // Fallback: crear algunos jugadores de prueba
    console.log('Using fallback test data...');
    const testPlayers = [
      { id: 1, nombre: 'Test Player 1', posicion: 'Delantero', valor_mercado: 10000000 },
      { id: 2, nombre: 'Test Player 2', posicion: 'Defensa', valor_mercado: 20000000 },
      { id: 3, nombre: 'Test Player 3', posicion: 'Centrocampista', valor_mercado: 15000000 }
    ];
    
    const shuffled = [...testPlayers].sort(() => 0.5 - Math.random());
    const player1 = shuffled[0];
    const player2 = shuffled[1];
    
    res.render('jugar_quien_vale_mas', { 
      user: req.session.user, 
      player1, 
      player2, 
      dificultad: dificultad || 'facil'
    });
  }
};;