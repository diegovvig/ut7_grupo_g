import fetch from 'node-fetch';

const API = process.env.API_URL ?? 'http://localhost:3000';

export const listarJugadores = async (req, res) => {
  const response = await fetch(`${API}/jugadores`);
  let jugadores = await response.json();

  const sort = req.query.sort;
  const order = (req.query.order || 'asc').toLowerCase();

  const allowed = ['id','nombre','edad','goles','asistencias','equipo'];
  if (sort && allowed.includes(sort)) {
    jugadores.sort((a,b) => {
      const av = a[sort];
      const bv = b[sort];
      if (av == null) return 1;
      if (bv == null) return -1;
      if (!isNaN(av) && !isNaN(bv)) {
        return (Number(av) - Number(bv)) * (order === 'asc' ? 1 : -1);
      }
      return String(av).localeCompare(String(bv)) * (order === 'asc' ? 1 : -1);
    });
  }

  res.render('jugadores', { jugadores, sort, order });
};

export const crearJugador = async (req, res) => {
  await fetch(`${API}/jugadores`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req.body)
  });
  res.redirect('/jugadores');
};

export const borrarJugador = async (req, res) => {
  await fetch(`${API}/jugadores/${req.params.id}`, { method: 'DELETE' });
  res.redirect('/jugadores');
};
