/*
  Controller SSR - Equipos
  - Este fichero actúa como puente entre la vista SSR y la API REST.
  - Hace peticiones a la API (fetch) para obtener/crear/borrar equipos
  - Implementa lógica de ordenación para la vista antes de renderizar
*/
import fetch from 'node-fetch';

// URL base de la API REST (se toma de .env o usa el fallback a localhost)
const API = process.env.API_URL ?? 'http://localhost:3000';

/*
  listarEquipos(req, res)
  - Bloque: petición a la API para obtener todos los equipos
  - Bloque: parseo del JSON recibido
  - Bloque: lectura de parámetros `sort` y `order` de la query string
  - Bloque: validación del campo a ordenar y algoritmo de ordenación
  - Bloque: renderiza la vista `equipos` pasando los datos y el estado de orden
*/
export const listarEquipos = async (req, res) => {
  // Petición a la API REST para obtener la lista de equipos
  const response = await fetch(`${API}/equipos`);
  let equipos = await response.json();

  // Obtener ligas para mapear IDs a nombres
  const ligasResp = await fetch(`${API}/ligas`);
  const ligas = await ligasResp.json();
  const ligaMap = {};
  ligas.forEach(l => { ligaMap[String(l.id)] = l.nombre; });

  // Añadir propiedad legible con el nombre de la liga
  equipos = equipos.map(e => {
    // Si la liga viene como objeto con nombre ya, usarlo
    if (e.liga && typeof e.liga === 'object') {
      return { ...e, ligaNombre: e.liga.nombre ?? e.liga.id };
    }
    // Buscar por id como string o número
    const key = e.liga == null ? null : String(e.liga);
    return { ...e, ligaNombre: (key && ligaMap[key]) ? ligaMap[key] : e.liga };
  });

  // Lectura de parámetros de ordenación desde la querystring
  const sort = req.query.sort;
  const order = (req.query.order || 'asc').toLowerCase();

  // Búsqueda
  const search = req.query.search;
  if (search && search.length >= 3) {
    equipos = equipos.filter(equipo =>
      equipo.nombre.toLowerCase().includes(search.toLowerCase()) ||
      (equipo.presupuesto && equipo.presupuesto.toString().toLowerCase().includes(search.toLowerCase())) ||
      (equipo.titulos && equipo.titulos.toString().toLowerCase().includes(search.toLowerCase())) ||
      (equipo.estadio && equipo.estadio.toLowerCase().includes(search.toLowerCase())) ||
      (equipo.ligaNombre && equipo.ligaNombre.toLowerCase().includes(search.toLowerCase()))
    );
  }

  // Campos permitidos para ordenación
  const allowed = ['id','nombre','presupuesto','titulos','estadio','liga'];
  if (sort && allowed.includes(sort)) {
    // Ordenación genérica: gestiona valores nulos, numéricos y texto
    equipos.sort((a,b) => {
      // Si se ordena por liga, usar el nombre mapeado
      const av = sort === 'liga' ? a.ligaNombre : a[sort];
      const bv = sort === 'liga' ? b.ligaNombre : b[sort];
      if (av == null) return 1; // envía nulos al final
      if (bv == null) return -1;
      // Si ambos son numéricos, comparar como números
      if (!isNaN(av) && !isNaN(bv)) {
        return (Number(av) - Number(bv)) * (order === 'asc' ? 1 : -1);
      }
      // Comparación para strings usando localeCompare
      return String(av).localeCompare(String(bv)) * (order === 'asc' ? 1 : -1);
    });
  }

  // Renderiza la vista SSR con los equipos y parámetros de orden
  // Paginación
  const page = parseInt(req.query.page) || 1;
  const limit = 20;
  const total = equipos.length;
  const totalPages = Math.ceil(total / limit);
  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + limit;
  const paginatedEquipos = equipos.slice(startIndex, endIndex);

  res.render('equipos', { equipos: paginatedEquipos, sort, order, user: req.session.user, currentPage: page, totalPages, total, search });
};

/*
  crearEquipo(req, res)
  - Bloque: reenvía `req.body` a la API REST mediante POST
  - Bloque: redirección a la lista SSR una vez creada la entidad
*/
export const crearEquipo = async (req, res) => {
  await fetch(`${API}/equipos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req.body)
  });
  res.redirect('/equipos');
};

/*
  borrarEquipo(req, res)
  - Bloque: invoca DELETE contra la API REST usando el id de params
  - Bloque: redirige a la vista de listado tras la eliminación
*/
export const borrarEquipo = async (req, res) => {
  await fetch(`${API}/equipos/${req.params.id}`, { method: 'DELETE' });
  res.redirect('/equipos');
};

/*
  mostrarCrearEquipo(req, res)
  - Renderiza la vista de creación de equipo
*/
export const mostrarCrearEquipo = (req, res) => {
  // Obtener ligas para poblar el select
  fetch(`${API}/ligas`)
    .then(r => r.json())
    .then(ligas => {
      res.render('crear_equipo', { ligas, user: req.session.user });
    })
    .catch(() => {
      res.render('crear_equipo', { ligas: [], user: req.session.user });
    });
};

/*
  mostrarEditarEquipo(req, res)
  - Obtiene el equipo por id de la API y renderiza el formulario de edición
*/
export const mostrarEditarEquipo = async (req, res) => {
  // Obtener equipo y ligas para poblar el select de ligas
  const response = await fetch(`${API}/equipos/${req.params.id}`);
  const equipo = await response.json();
  try {
    const ligasResp = await fetch(`${API}/ligas`);
    const ligas = await ligasResp.json();
    res.render('editar_equipo', { equipo, ligas, user: req.session.user });
  } catch (err) {
    res.render('editar_equipo', { equipo, ligas: [], user: req.session.user });
  }
};

/*
  editarEquipo(req, res)
  - Envía un PUT a la API para actualizar el equipo
*/
export const editarEquipo = async (req, res) => {
  await fetch(`${API}/equipos/${req.params.id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req.body)
  });
  res.redirect('/equipos');
};
