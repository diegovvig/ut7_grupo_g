import fetch from 'node-fetch';

const API = process.env.API_URL ?? 'http://localhost:3000';

export const listarEquipos = async (req, res) => {
  const response = await fetch(`${API}/equipos`);
  let equipos = await response.json();

  const sort = req.query.sort;
  const order = (req.query.order || 'asc').toLowerCase();

  const allowed = ['id','nombre','presupuesto','titulos','estadio','liga'];
  if (sort && allowed.includes(sort)) {
    equipos.sort((a,b) => {
      const av = a[sort];
      const bv = b[sort];
      if (av == null) return 1;
      if (bv == null) return -1;
      if (!isNaN(av) && !isNaN(bv)) {
        return (Number(av) - Number(bv)) * (order === 'asc' ? 1 : -1);
      }
      return String(av).localeCompare(String(bv)) * (order === 'asc' ? 1 : -1);
    });
  }

  res.render('equipos', { equipos, sort, order });
};

export const crearEquipo = async (req, res) => {
  await fetch(`${API}/equipos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req.body)
  });
  res.redirect('/equipos');
};

export const borrarEquipo = async (req, res) => {
  await fetch(`${API}/equipos/${req.params.id}`, { method: 'DELETE' });
  res.redirect('/equipos');
};
