/*
  Controller SSR - Adivina Jugador
  - Maneja la lógica del juego de adivinar el jugador
*/
import fetch from 'node-fetch';

// Base URL de la API (falla a localhost:3000 si no está en .env)
const API = process.env.API_URL ?? 'http://localhost:3000';

/*
  mostrarAdivinanza(req, res)
  - Inicializa el juego: selecciona un jugador aleatorio y lo guarda en la sesión
  - Renderiza la vista de adivinanza
*/
export const mostrarAdivinanza = async (req, res) => {
  try {
    // Obtener todos los jugadores
    const response = await fetch(`${API}/jugadores`);
    const jugadores = await response.json();

    if (jugadores.length === 0) {
      return res.status(500).send('No hay jugadores disponibles');
    }

    // Seleccionar un jugador aleatorio
    const jugadorSecreto = jugadores[Math.floor(Math.random() * jugadores.length)];

    // Calcular edad del secreto
    let secretEdad = 'N/A';
    if (jugadorSecreto.fecha_nacimiento) {
      const fechaNacimiento = new Date(jugadorSecreto.fecha_nacimiento);
      if (!isNaN(fechaNacimiento.getTime())) {
        const hoy = new Date();
        secretEdad = hoy.getFullYear() - fechaNacimiento.getFullYear() - (hoy < new Date(hoy.getFullYear(), fechaNacimiento.getMonth(), fechaNacimiento.getDate()) ? 1 : 0);
      }
    }

    // Valor del secreto
    const secretValor = jugadorSecreto.valor_mercado;

    // Nacionalidad y posición del secreto
    const secretNacionalidad = jugadorSecreto.nacionalidad;
    const secretPosicion = jugadorSecreto.posicion;

    // Guardar en sesión
    req.session.jugadorSecreto = jugadorSecreto;
    req.session.secretEdad = secretEdad;
    req.session.secretValor = secretValor;
    req.session.secretNacionalidad = secretNacionalidad;
    req.session.secretPosicion = secretPosicion;
    req.session.intentos = [];
    req.session.intentosRestantes = 7;

    res.render('adivina_jugador', { user: req.session.user, intentosRestantes: 7, intentos: [], secretEdad, secretValor, secretNacionalidad, secretPosicion });
  } catch (error) {
    console.error('Error al inicializar adivinanza:', error);
    res.status(500).send('Error interno del servidor');
  }
};

/*
  buscarJugadores(req, res)
  - Endpoint AJAX para buscar jugadores por nombre (mínimo 3 letras)
  - Devuelve lista de jugadores que coinciden
*/
export const buscarJugadores = async (req, res) => {
  try {
    const query = req.query.q;
    if (!query || query.length < 3) {
      return res.json([]);
    }

    const response = await fetch(`${API}/jugadores`);
    const jugadores = await response.json();

    // Obtener equipos para mapear
    const equiposResp = await fetch(`${API}/equipos`);
    const equipos = await equiposResp.json();
    const equipoMap = {};
    equipos.forEach(e => { equipoMap[e.id] = e.nombre; });

    // Filtrar por nombre
    let resultados = jugadores.filter(j =>
      j.nombre.toLowerCase().includes(query.toLowerCase())
    );

    // Filtrar jugadores ya intentados
    const intentosIds = (req.session.intentos || []).map(i => i.jugador.id);
    resultados = resultados.filter(j => !intentosIds.includes(j.id));

    // Mapear con nombre de equipo
    const resultadosMapeados = await Promise.all(resultados.map(async j => {
      let equipoNombre = 'Sin equipo';
      if (j.equipo) {
        if (typeof j.equipo === 'object' && j.equipo.nombre) {
          equipoNombre = j.equipo.nombre;
        } else if (equipoMap[j.equipo]) {
          equipoNombre = equipoMap[j.equipo];
        }
      }

      // Calcular edad
      let edad = 'N/A';
      if (j.fecha_nacimiento) {
        const fechaNacimiento = new Date(j.fecha_nacimiento);
        if (!isNaN(fechaNacimiento.getTime())) {
          const hoy = new Date();
          edad = hoy.getFullYear() - fechaNacimiento.getFullYear() - (hoy < new Date(hoy.getFullYear(), fechaNacimiento.getMonth(), fechaNacimiento.getDate()) ? 1 : 0);
        }
      }

      return {
        id: j.id,
        nombre: j.nombre || 'N/A',
        nacionalidad: j.nacionalidad || 'N/A',
        posicion: j.posicion || 'N/A',
        edad: edad,
        equipoNombre: equipoNombre,
        valor_mercado: j.valor_mercado != null ? j.valor_mercado : 'N/A',
        partidos: j.partidos != null ? j.partidos : 'N/A',
        goles: j.goles != null ? j.goles : 'N/A',
        asistencias: j.asistencias != null ? j.asistencias : 'N/A'
      };
    }));

    res.json(resultadosMapeados);
  } catch (error) {
    console.error('Error al buscar jugadores:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

/*
  intentarAdivinar(req, res)
  - Maneja el intento de adivinar: recibe el ID del jugador seleccionado
  - Comprueba si es correcto, actualiza intentos, etc.
*/
export const intentarAdivinar = async (req, res) => {
  try {
    const { jugadorId } = req.body;

    if (!req.session.jugadorSecreto) {
      return res.status(400).json({ error: 'Juego no inicializado' });
    }

    if (req.session.intentosRestantes <= 0) {
      return res.status(400).json({ error: 'No quedan intentos' });
    }

    // Obtener el jugador seleccionado
    const response = await fetch(`${API}/jugadores/${jugadorId}`);
    if (!response.ok) {
      return res.status(404).json({ error: 'Jugador no encontrado' });
    }
    const jugadorSeleccionado = await response.json();

    // Obtener nombre del equipo si es necesario
    let equipoNombre = 'Sin equipo';
    if (jugadorSeleccionado.equipo) {
      if (typeof jugadorSeleccionado.equipo === 'object' && jugadorSeleccionado.equipo.nombre) {
        equipoNombre = jugadorSeleccionado.equipo.nombre;
      } else if (typeof jugadorSeleccionado.equipo === 'number' || typeof jugadorSeleccionado.equipo === 'string') {
        try {
          const equipoResp = await fetch(`${API}/equipos/${jugadorSeleccionado.equipo}`);
          if (equipoResp.ok) {
            const equipo = await equipoResp.json();
            equipoNombre = equipo.nombre;
          }
        } catch (error) {
          console.error('Error obteniendo equipo:', error);
        }
      }
    }

    // Comprobar si es correcto
    const esCorrecto = jugadorSeleccionado.id === req.session.jugadorSecreto.id;

    // Calcular edad
    let edad = 'N/A';
    if (jugadorSeleccionado.fecha_nacimiento) {
      const fechaNacimiento = new Date(jugadorSeleccionado.fecha_nacimiento);
      if (!isNaN(fechaNacimiento.getTime())) {
        const hoy = new Date();
        edad = hoy.getFullYear() - fechaNacimiento.getFullYear() - (hoy < new Date(hoy.getFullYear(), fechaNacimiento.getMonth(), fechaNacimiento.getDate()) ? 1 : 0);
      }
    }

    // Añadir a intentos
    const jugadorCompleto = {
      id: jugadorSeleccionado.id,
      nombre: jugadorSeleccionado.nombre || 'N/A',
      edad: edad,
      nacionalidad: jugadorSeleccionado.nacionalidad || 'N/A',
      posicion: jugadorSeleccionado.posicion || 'N/A',
      fecha_nacimiento: jugadorSeleccionado.fecha_nacimiento || 'N/A',
      equipoNombre: equipoNombre,
      valor_mercado: jugadorSeleccionado.valor_mercado != null ? jugadorSeleccionado.valor_mercado : 'N/A',
      partidos: jugadorSeleccionado.partidos != null ? jugadorSeleccionado.partidos : 'N/A',
      goles: jugadorSeleccionado.goles != null ? jugadorSeleccionado.goles : 'N/A',
      asistencias: jugadorSeleccionado.asistencias != null ? jugadorSeleccionado.asistencias : 'N/A'
    };
    req.session.intentos.push({
      jugador: jugadorCompleto,
      correcto: esCorrecto
    });

    req.session.intentosRestantes--;

    const terminado = esCorrecto || req.session.intentosRestantes <= 0;

    res.json({
      correcto: esCorrecto,
      terminado,
      intentosRestantes: req.session.intentosRestantes,
      secretEdad: req.session.secretEdad,
      secretValor: req.session.secretValor,
      secretNacionalidad: req.session.secretNacionalidad,
      secretPosicion: req.session.secretPosicion,
      correctPlayer: terminado && !esCorrecto ? req.session.jugadorSecreto : null,
      jugador: {
        id: jugadorSeleccionado.id,
        nombre: jugadorSeleccionado.nombre,
        edad: edad,
        nacionalidad: jugadorSeleccionado.nacionalidad,
        posicion: jugadorSeleccionado.posicion,
        fecha_nacimiento: jugadorSeleccionado.fecha_nacimiento,
        equipoNombre: equipoNombre,
        valor_mercado: jugadorSeleccionado.valor_mercado,
        partidos: jugadorSeleccionado.partidos,
        goles: jugadorSeleccionado.goles,
        asistencias: jugadorSeleccionado.asistencias
      }
    });
  } catch (error) {
    console.error('Error al intentar adivinar:', error);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
};

/*
  reiniciarJuego(req, res)
  - Reinicia el juego: selecciona nuevo jugador secreto
*/
export const reiniciarJuego = async (req, res) => {
  try {
    // Obtener todos los jugadores
    const response = await fetch(`${API}/jugadores`);
    const jugadores = await response.json();

    if (jugadores.length === 0) {
      return res.status(500).send('No hay jugadores disponibles');
    }

    // Seleccionar un jugador aleatorio
    const jugadorSecreto = jugadores[Math.floor(Math.random() * jugadores.length)];

    // Reiniciar sesión
    req.session.jugadorSecreto = jugadorSecreto;
    req.session.intentos = [];
    req.session.intentosRestantes = 7;

    res.redirect('/adivina-jugador');
  } catch (error) {
    console.error('Error al reiniciar juego:', error);
    res.status(500).send('Error interno del servidor');
  }
};