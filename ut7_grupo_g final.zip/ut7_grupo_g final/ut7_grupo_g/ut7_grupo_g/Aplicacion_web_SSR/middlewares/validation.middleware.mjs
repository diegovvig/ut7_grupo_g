export const validateBody = (requiredFields = []) => {
  return (req, res, next) => {
    const errors = [];

    for (const field of requiredFields) {
      if (
        !req.body.hasOwnProperty(field) ||
        req.body[field] === null ||
        req.body[field] === ""
      ) {
        errors.push(`El campo '${field}' es obligatorio`);
      }
    }

    if (errors.length > 0) {
      return res.status(400).json({
        errors
      });
    }

    next();
  };
};
