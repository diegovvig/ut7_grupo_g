import fetch from 'node-fetch';

const API = process.env.API_URL ?? 'http://localhost:3000';

export const listarJugadores = async (req, res) => {
  const response = await fetch(`${API}/jugadores`);
  let jugadores = await response.json();

  const equiposResp = await fetch(`${API}/equipos`);
  const equipos = await equiposResp.json();
  const equipoMap = {};
  equipos.forEach(e => { equipoMap[String(e.id)] = e.nombre; });

  jugadores = jugadores.map(j => {
    if (j.equipo && typeof j.equipo === 'object') {
      return { ...j, equipoNombre: j.equipo.nombre ?? j.equipo.id };
    }
    const key = j.equipo == null ? null : String(j.equipo);
    return { ...j, equipoNombre: (key && equipoMap[key]) ? equipoMap[key] : j.equipo };
  });

  const sort = req.query.sort;
  const order = (req.query.order || 'asc').toLowerCase();

  const allowed = ['id','nombre','edad','goles','asistencias','equipo'];
  if (sort && allowed.includes(sort)) {
    jugadores.sort((a,b) => {
      const av = sort === 'equipo' ? a.equipoNombre : a[sort];
      const bv = sort === 'equipo' ? b.equipoNombre : b[sort];
      if (av == null) return 1;
      if (bv == null) return -1;
      if (!isNaN(av) && !isNaN(bv)) {
        return (Number(av) - Number(bv)) * (order === 'asc' ? 1 : -1);
      }
      return String(av).localeCompare(String(bv)) * (order === 'asc' ? 1 : -1);
    });
  }

  res.render('jugadores', { jugadores, sort, order });
};

export const crearJugador = async (req, res) => {
  await fetch(`${API}/jugadores`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req.body)
  });
  res.redirect('/jugadores');
};

export const borrarJugador = async (req, res) => {
  await fetch(`${API}/jugadores/${req.params.id}`, { method: 'DELETE' });
  res.redirect('/jugadores');
};

export const mostrarCrearJugador = (req, res) => {
  fetch(`${API}/equipos`)
    .then(r => r.json())
    .then(equipos => {
      res.render('crear_jugador', { equipos });
    })
    .catch(() => {
      res.render('crear_jugador', { equipos: [] });
    });
};

export const mostrarEditarJugador = async (req, res) => {
  const response = await fetch(`${API}/jugadores/${req.params.id}`);
  const jugador = await response.json();
  try {
    const equiposResp = await fetch(`${API}/equipos`);
    const equipos = await equiposResp.json();
    res.render('editar_jugador', { jugador, equipos });
  } catch (err) {
    res.render('editar_jugador', { jugador, equipos: [] });
  }
};

export const editarJugador = async (req, res) => {
  await fetch(`${API}/jugadores/${req.params.id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req.body)
  });
  res.redirect('/jugadores');
};
