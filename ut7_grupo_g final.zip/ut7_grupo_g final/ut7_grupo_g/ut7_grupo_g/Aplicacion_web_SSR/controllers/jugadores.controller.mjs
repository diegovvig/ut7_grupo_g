/*
  Controller SSR - Jugadores
  - Similar al controller de equipos: obtiene datos de la API REST
  - Proporciona funciones para listar, crear y borrar jugadores desde la capa SSR
*/
import fetch from 'node-fetch';

// Base URL de la API (falla a localhost:3000 si no está en .env)
const API = process.env.API_URL ?? 'http://localhost:3000';

/*
  listarJugadores(req, res)
  - Bloque: petición a la API para recuperar jugadores
  - Bloque: parseo y ordenación opcional (campos permitidos definidos en `allowed`)
  - Bloque: renderizado de la vista `jugadores` con datos y estado de orden
*/
export const listarJugadores = async (req, res) => {
  // Petición a la API
  const response = await fetch(`${API}/jugadores`);
  let jugadores = await response.json();

  // Obtener equipos para mapear IDs a nombres
  const equiposResp = await fetch(`${API}/equipos`);
  const equipos = await equiposResp.json();
  const equipoMap = {};
  equipos.forEach(e => { equipoMap[String(e.id)] = e.nombre; });

  // Añadir propiedad legible con el nombre del equipo
  jugadores = jugadores.map(j => {
    // Si el equipo viene como objeto con nombre
    if (j.equipo && typeof j.equipo === 'object') {
      return { ...j, equipoNombre: j.equipo.nombre ?? j.equipo.id };
    }
    const key = j.equipo == null ? null : String(j.equipo);
    return { ...j, equipoNombre: (key && equipoMap[key]) ? equipoMap[key] : j.equipo };
  });

  // Parámetros de ordenación desde querystring
  const sort = req.query.sort;
  const order = (req.query.order || 'asc').toLowerCase();

  // Campos permitidos para ordenar
  const allowed = ['id','nombre','edad','goles','asistencias','equipo'];
  if (sort && allowed.includes(sort)) {
    // Lógica de ordenación: nulos al final, numéricos por número, strings por localeCompare
    jugadores.sort((a,b) => {
      // Si se ordena por equipo, usar el nombre mapeado
      const av = sort === 'equipo' ? a.equipoNombre : a[sort];
      const bv = sort === 'equipo' ? b.equipoNombre : b[sort];
      if (av == null) return 1;
      if (bv == null) return -1;
      if (!isNaN(av) && !isNaN(bv)) {
        return (Number(av) - Number(bv)) * (order === 'asc' ? 1 : -1);
      }
      return String(av).localeCompare(String(bv)) * (order === 'asc' ? 1 : -1);
    });
  }

  // Renderiza la vista SSR con la lista ordenada/filtrada
  res.render('jugadores', { jugadores, sort, order });
};

/*
  crearJugador(req, res)
  - Bloque: reenvía el formulario a la API con método POST
  - Bloque: redirección a la lista de jugadores tras la creación
*/
export const crearJugador = async (req, res) => {
  await fetch(`${API}/jugadores`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req.body)
  });
  res.redirect('/jugadores');
};

/*
  borrarJugador(req, res)
  - Bloque: invoca DELETE en la API usando el id de `req.params`
  - Bloque: redirige a la vista de listado
*/
export const borrarJugador = async (req, res) => {
  await fetch(`${API}/jugadores/${req.params.id}`, { method: 'DELETE' });
  res.redirect('/jugadores');
};

/*
  mostrarCrearJugador(req, res)
  - Renderiza la vista de creación de jugador
*/
export const mostrarCrearJugador = (req, res) => {
  // Obtener equipos para poblar el select de equipos
  fetch(`${API}/equipos`)
    .then(r => r.json())
    .then(equipos => {
      res.render('crear_jugador', { equipos });
    })
    .catch(() => {
      res.render('crear_jugador', { equipos: [] });
    });
};

/*
  mostrarEditarJugador(req, res)
  - Obtiene el jugador por id y renderiza la vista de edición
*/
export const mostrarEditarJugador = async (req, res) => {
  // Obtener jugador y equipos para poblar select
  const response = await fetch(`${API}/jugadores/${req.params.id}`);
  const jugador = await response.json();
  try {
    const equiposResp = await fetch(`${API}/equipos`);
    const equipos = await equiposResp.json();
    res.render('editar_jugador', { jugador, equipos });
  } catch (err) {
    res.render('editar_jugador', { jugador, equipos: [] });
  }
};

/*
  editarJugador(req, res)
  - Envía PUT a la API para actualizar el jugador
*/
export const editarJugador = async (req, res) => {
  await fetch(`${API}/jugadores/${req.params.id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req.body)
  });
  res.redirect('/jugadores');
};
