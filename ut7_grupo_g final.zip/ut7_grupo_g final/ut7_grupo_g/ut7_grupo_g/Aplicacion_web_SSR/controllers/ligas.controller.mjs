import fetch from 'node-fetch';

const API = process.env.API_URL ?? 'http://localhost:3000';

export const listarLigas = async (req, res) => {
  const response = await fetch(`${API}/ligas`);
  let ligas = await response.json();

  const sort = req.query.sort;
  const order = (req.query.order || 'asc').toLowerCase();

  const allowed = ['id','nombre','pais','maximo_equipo_ganador'];
  if (sort && allowed.includes(sort)) {
    ligas.sort((a,b) => {
      const av = a[sort];
      const bv = b[sort];
      if (av == null) return 1;
      if (bv == null) return -1;
      if (!isNaN(av) && !isNaN(bv)) {
        return (Number(av) - Number(bv)) * (order === 'asc' ? 1 : -1);
      }
      return String(av).localeCompare(String(bv)) * (order === 'asc' ? 1 : -1);
    });
  }

  res.render('ligas', { ligas, sort, order });
};

export const mostrarCrearLiga = (req, res) => {
  res.render('crear_liga');
};

export const crearLiga = async (req, res) => {
  const response = await fetch(`${API}/ligas`);
  const ligas = await response.json();
  const ids = ligas.map(l => l.id).sort((a, b) => a - b);
  
  let nextId = 1;
  for (const id of ids) {
    if (id === nextId) {
      nextId++;
    } else if (id > nextId) {
      break;
    }
  }
  
  const body = { ...req.body, id: nextId };
  
  await fetch(`${API}/ligas`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  res.redirect('/ligas');
};

export const mostrarEditarLiga = async (req, res) => {
  const response = await fetch(`${API}/ligas/${req.params.id}`);
  const liga = await response.json();
  res.render('editar_liga', { liga });
};

export const editarLiga = async (req, res) => {
  await fetch(`${API}/ligas/${req.params.id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req.body)
  });
  res.redirect('/ligas');
};

export const borrarLiga = async (req, res) => {
  await fetch(`${API}/ligas/${req.params.id}`, { method: 'DELETE' });
  res.redirect('/ligas');
};
