/*
  Controller SSR - Ligas
  - Obtiene/crea/borra ligas consultando la API REST
  - Añade ordenación simple para mostrar en la vista `ligas`.
*/
import fetch from 'node-fetch';

// URL base de la API REST
const API = process.env.API_URL ?? 'http://localhost:3000';

/*
  listarLigas(req, res)
  - Bloque: solicita ligas a la API
  - Bloque: aplica ordenación opcional en función de query params
  - Bloque: renderiza la vista `ligas` con los datos
*/
export const listarLigas = async (req, res) => {
  // Petición a la API REST
  const response = await fetch(`${API}/ligas`);
  let ligas = await response.json();

  // Lectura de parámetros para ordenar
  const sort = req.query.sort;
  const order = (req.query.order || 'asc').toLowerCase();

  // Campos permitidos para ordenación
  const allowed = ['id','nombre','pais','maximo_equipo_ganador'];
  if (sort && allowed.includes(sort)) {
    // Ordena manejando nulos, números y strings
    ligas.sort((a,b) => {
      const av = a[sort];
      const bv = b[sort];
      if (av == null) return 1;
      if (bv == null) return -1;
      if (!isNaN(av) && !isNaN(bv)) {
        return (Number(av) - Number(bv)) * (order === 'asc' ? 1 : -1);
      }
      return String(av).localeCompare(String(bv)) * (order === 'asc' ? 1 : -1);
    });
  }

  // Renderiza la vista con las ligas y estado de orden
  res.render('ligas', { ligas, sort, order });
};

/*
  mostrarCrearLiga(req, res)
  - Bloque: renderiza la vista de creación de liga
*/
export const mostrarCrearLiga = (req, res) => {
  res.render('crear_liga');
};

/*
  crearLiga(req, res)
  - Bloque: obtiene las ligas existentes para calcular el primer ID disponible
  - Bloque: asigna el ID al body del formulario
  - Bloque: reenvía datos del formulario a la API mediante POST
  - Bloque: redirección a la lista de ligas
*/
export const crearLiga = async (req, res) => {
  // Obtener ligas existentes para calcular el primer ID disponible
  const response = await fetch(`${API}/ligas`);
  const ligas = await response.json();
  const ids = ligas.map(l => l.id).sort((a, b) => a - b);
  
  // Encontrar el primer ID disponible (el más pequeño positivo entero no usado)
  let nextId = 1;
  for (const id of ids) {
    if (id === nextId) {
      nextId++;
    } else if (id > nextId) {
      break;
    }
  }
  
  // Asignar el ID calculado al body
  const body = { ...req.body, id: nextId };
  
  await fetch(`${API}/ligas`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  res.redirect('/ligas');
};

/*
  mostrarEditarLiga(req, res)
  - Bloque: obtiene la liga por id de la API
  - Bloque: renderiza la vista de edición con los datos
*/
export const mostrarEditarLiga = async (req, res) => {
  const response = await fetch(`${API}/ligas/${req.params.id}`);
  const liga = await response.json();
  res.render('editar_liga', { liga });
};

/*
  editarLiga(req, res)
  - Bloque: actualiza la liga en la API mediante PUT
  - Bloque: redirección a la lista de ligas
*/
export const editarLiga = async (req, res) => {
  await fetch(`${API}/ligas/${req.params.id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req.body)
  });
  res.redirect('/ligas');
};

/*
  borrarLiga(req, res)
  - Bloque: invoca DELETE en la API con el id pasado en params
  - Bloque: redirecciona a la vista de ligas
*/
export const borrarLiga = async (req, res) => {
  await fetch(`${API}/ligas/${req.params.id}`, { method: 'DELETE' });
  res.redirect('/ligas');
};
