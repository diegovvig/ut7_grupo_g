import fetch from 'node-fetch';

const API = process.env.API_URL ?? 'http://localhost:3000';

export const listarEquipos = async (req, res) => {
  const response = await fetch(`${API}/equipos`);
  let equipos = await response.json();

  const ligasResp = await fetch(`${API}/ligas`);
  const ligas = await ligasResp.json();
  const ligaMap = {};
  ligas.forEach(l => { ligaMap[String(l.id)] = l.nombre; });

  equipos = equipos.map(e => {
    if (e.liga && typeof e.liga === 'object') {
      return { ...e, ligaNombre: e.liga.nombre ?? e.liga.id };
    }
    const key = e.liga == null ? null : String(e.liga);
    return { ...e, ligaNombre: (key && ligaMap[key]) ? ligaMap[key] : e.liga };
  });

  const sort = req.query.sort;
  const order = (req.query.order || 'asc').toLowerCase();

  const allowed = ['id','nombre','presupuesto','titulos','estadio','liga'];
  if (sort && allowed.includes(sort)) {
    equipos.sort((a,b) => {
      const av = sort === 'liga' ? a.ligaNombre : a[sort];
      const bv = sort === 'liga' ? b.ligaNombre : b[sort];
      if (av == null) return 1;
      if (bv == null) return -1;
      if (!isNaN(av) && !isNaN(bv)) {
        return (Number(av) - Number(bv)) * (order === 'asc' ? 1 : -1);
      }
      return String(av).localeCompare(String(bv)) * (order === 'asc' ? 1 : -1);
    });
  }

  res.render('equipos', { equipos, sort, order });
};

export const crearEquipo = async (req, res) => {
  await fetch(`${API}/equipos`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req.body)
  });
  res.redirect('/equipos');
};

export const borrarEquipo = async (req, res) => {
  await fetch(`${API}/equipos/${req.params.id}`, { method: 'DELETE' });
  res.redirect('/equipos');
};

export const mostrarCrearEquipo = (req, res) => {
  fetch(`${API}/ligas`)
    .then(r => r.json())
    .then(ligas => {
      res.render('crear_equipo', { ligas });
    })
    .catch(() => {
      res.render('crear_equipo', { ligas: [] });
    });
};

export const mostrarEditarEquipo = async (req, res) => {
  const response = await fetch(`${API}/equipos/${req.params.id}`);
  const equipo = await response.json();
  try {
    const ligasResp = await fetch(`${API}/ligas`);
    const ligas = await ligasResp.json();
    res.render('editar_equipo', { equipo, ligas });
  } catch (err) {
    res.render('editar_equipo', { equipo, ligas: [] });
  }
};

export const editarEquipo = async (req, res) => {
  await fetch(`${API}/equipos/${req.params.id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req.body)
  });
  res.redirect('/equipos');
};
