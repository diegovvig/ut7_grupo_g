# Documentación comentada - Aplicacion_web_SSR

A continuación se describen, bloque por bloque, los ficheros de la carpeta `Aplicacion_web_SSR`.

## `app.mjs`
- Bloque imports: importa `express`, `dotenv`, rutas y el middleware de error.
- Bloque carga de entorno: `dotenv.config()` para leer `.env` antes de usar variables.
- Bloque configuración de Express: `app.set('view engine', 'ejs')` y `app.set('views','./views')`.
- Bloque middlewares globales: `express.urlencoded`, `express.json` y `express.static('public')` para servir recursos estáticos.
- Bloque mounting de rutas: monta `indexRoutes`, `ligasRoutes`, `equiposRoutes` y `jugadoresRoutes` en sus paths (`/`, `/ligas`, `/equipos`, `/jugadores`).
- Bloque arranque del servidor: `app.listen(process.env.PORT, ...)` muestra URL en consola.
- Bloque manejo de errores: `app.use(errorHandler)` al final para capturar errores.

## `controllers/equipos.controller.mjs`
- Bloque imports y configuración: importa `node-fetch` y define `API` usando `process.env.API_URL` con fallback.
- Bloque `listarEquipos`: hace `fetch` a `GET ${API}/equipos`, parsea JSON; lee `req.query.sort` y `req.query.order`; valida que la columna solicitada esté en `allowed` y, si procede, ordena el array comparando numéricamente o por `localeCompare` para texto; finalmente `res.render('equipos', { equipos, sort, order })`.
- Bloque `crearEquipo`: `fetch` POST a `${API}/equipos` con `req.body` en JSON y redirección a `/equipos`.
- Bloque `borrarEquipo`: `fetch` DELETE a `${API}/equipos/:id` y redirección a `/equipos`.

## `controllers/jugadores.controller.mjs`
- Bloque imports y `API` similar al de equipos.
- Bloque `listarJugadores`: `fetch` a `${API}/jugadores`, parseo JSON, lógica de ordenación en función de `sort`/`order` (campos permitidos: id, nombre, edad, goles, asistencias, equipo) y `res.render('jugadores', { jugadores, sort, order })`.
- Bloque `crearJugador`: POST a `${API}/jugadores` con `req.body` y redirección a `/jugadores`.
- Bloque `borrarJugador`: DELETE a `${API}/jugadores/:id` y redirección.

## `controllers/ligas.controller.mjs`
- Bloque imports y `API` igual que anteriores.
- Bloque `listarLigas`: `fetch` a `${API}/ligas`, parseo y ordenación condicional por campos permitidos (`id`, `nombre`, `pais`, `maximo_equipo_ganador`), y `res.render('ligas', { ligas, sort, order })`.
- Bloque `crearLiga`: POST a `${API}/ligas` con `req.body`.
- Bloque `borrarLiga`: DELETE a `${API}/ligas/:id`.

## `middlewares/validation.middleware.mjs`
- Bloque factory `validateBody(requiredFields)`: devuelve un middleware que itera `requiredFields` y comprueba `req.body` para presencia y no vacío.
- Bloque respuesta de error: si hay campos obligatorios ausentes responde `400` con `{ errors }`.
- Bloque next: si todo correcto llama `next()`.

## `middlewares/error.middleware.mjs`
- Bloque handler de errores: función con firma `(err, req, res, next)` que hace `console.error(err)` y responde JSON con `status` del error (o 500) y `error: err.message`.

## `middlewares/auth.middleware.mjs`
- Bloque inicialización Firebase Admin: si `admin.apps` está vacío inicializa el SDK con credenciales leídas de variables de entorno (`FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY`) (reemplazo de `\n` en la clave privada).
- Bloque `authenticate`: middleware que lee `Authorization` header tipo `Bearer <token>`; verifica token con `admin.auth().verifyIdToken(token)`; si válido añade `req.user = decodedToken` y `next()`; en caso contrario responde `401`.

## `routes/index.routes.mjs`
- Bloque router raíz: `router.get('/')` que renderiza la vista `home`.

## `routes/equipos.routes.mjs`
- Bloque imports del controller y creación de `Router()`.
- Bloque rutas: `GET /` -> `listarEquipos`; `POST /crear` -> `crearEquipo`; `POST /borrar/:id` -> `borrarEquipo`.

## `routes/jugadores.routes.mjs`
- Bloque rutas análogas: `GET /` -> `listarJugadores`; `POST /crear`; `POST /borrar/:id`.

## `routes/ligas.routes.mjs`
- Bloque rutas: `GET /` -> `listarLigas`; `POST /crear`; `POST /borrar/:id`.

## Vistas EJS
- `views/home.ejs`: estructura HTML básica, include de `styles.css`, nav con enlaces a las secciones y bloque principal con título y descripción.
- `views/equipos.ejs`: header/nav; encabezado `h2`; tabla `.data-table.sortable` con enlaces para ordenar columnas (parámetros `?sort=X&order=Y`); cuerpo relleno con `<% equipos.forEach %>` mostrando campos (id, nombre, presupuesto, títulos, estadio, liga) y formulario por fila para borrar equipo.
- `views/jugadores.ejs`: similar a `equipos.ejs` pero con columnas y campos de jugador (nacionalidad, posición, fecha_nacimiento, valor_mercado, partidos, goles, asistencias) y formulario de borrado.
- `views/ligas.ejs`: nav, formulario simple para crear liga (`nombre`, `pais`), tabla listando ligas y botón para borrar por fila.

## `public/css/styles.css`
- Bloques principales: estilos globales del `body` (tipografía, fondo degradado, color de texto claro) para tema oscuro.
- Bloque navegación (`nav`) con estilo visual (gradiente, padding, border-radius, sombras), y reglas para `nav a` (espaciado, color, transformaciones hover).
- Bloque `.data-table` (hay dos conjuntos de reglas: uno para tema oscuro y otro para tema claro); reglas para `th/td`, alternancia de filas, hover y enlaces de ordenación.
- Bloque botones y formularios: estilos para `button`, `form input` y `form button`.
- Nota: el fichero contiene bloques duplicados y mezcla de tema oscuro y claro; conviene limpiar/normalizar si se desea coherencia.

## `public/js/charts.mjs`
- Archivo presente pero vacío: reservado para inicialización de gráficos (p. ej. Chart.js) y carga dinámica de datos.

## `package.json`
- Bloque metadatos (`name`, `version`, `main`).
- Bloque scripts: `dev` ejecuta `nodemon app.js` (ojo: en el proyecto el fichero principal se llama `app.mjs`, el script usa `app.js`).
- Bloque dependencias: `dotenv`, `ejs`, `express`, `node-fetch`.

---

Si quieres, puedo:
- Generar un `DOCUMENTACION_COMENTADA.md` unificado que incluya también la carpeta `Servicio API REST` (ahora me encargaría de esa parte). 
- O comentar cada fichero añadiendo comentarios en línea dentro de los propios `.mjs`/`.ejs` (modificar los ficheros del proyecto).

Indica cómo prefieres que continúe y procedo con la segunda parte (Servicio API REST).
