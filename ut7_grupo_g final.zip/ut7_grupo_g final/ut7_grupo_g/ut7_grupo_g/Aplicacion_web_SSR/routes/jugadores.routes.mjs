import { Router } from 'express';
import {
  listarJugadores,
  crearJugador,
  borrarJugador
} from '../controllers/jugadores.controller.mjs';

import {
  mostrarCrearJugador,
  mostrarEditarJugador,
  editarJugador
} from '../controllers/jugadores.controller.mjs';

const router = Router();

router.get('/', listarJugadores);

router.get('/crear', mostrarCrearJugador);

router.post('/crear', crearJugador);

router.get('/editar/:id', mostrarEditarJugador);

router.post('/editar/:id', editarJugador);

router.post('/borrar/:id', borrarJugador);

export default router;
