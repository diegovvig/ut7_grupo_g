/*
  index.routes.mjs
  - Router para la ruta raíz de la aplicación SSR
  - Devuelve la vista `home` con la navegación hacia las secciones
*/
import { Router } from 'express';

const router = Router();

// Ruta raíz: renderiza la página principal
router.get('/', (req, res) => {
  res.render('home', { user: req.session.user });
});

export default router;
