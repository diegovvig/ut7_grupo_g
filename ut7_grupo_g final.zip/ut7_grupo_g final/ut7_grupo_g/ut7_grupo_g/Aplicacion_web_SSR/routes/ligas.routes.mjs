import { Router } from 'express';
import {
  listarLigas,
  mostrarCrearLiga,
  crearLiga,
  mostrarEditarLiga,
  editarLiga,
  borrarLiga
} from '../controllers/ligas.controller.mjs';

const router = Router();

router.get('/', listarLigas);

router.get('/crear', mostrarCrearLiga);

router.post('/crear', crearLiga);

router.get('/editar/:id', mostrarEditarLiga);

router.post('/editar/:id', editarLiga);

export default router;
