import { Router } from 'express';
import {
  listarEquipos,
  mostrarCrearEquipo,
  crearEquipo,
  mostrarEditarEquipo,
  editarEquipo,
  borrarEquipo
} from '../controllers/equipos.controller.mjs';

const router = Router();

router.get('/', listarEquipos);

router.get('/crear', mostrarCrearEquipo);

router.post('/crear', crearEquipo);

router.get('/editar/:id', mostrarEditarEquipo);

router.post('/editar/:id', editarEquipo);

router.post('/borrar/:id', borrarEquipo);

export default router;
