export const Ligas = [
  { id: 1, nombre: 'LaLiga', pais: 'España', maximo_equipo_ganador: 5 },
  { id: 2, nombre: 'Premier League', pais: 'Inglaterra', maximo_equipo_ganador: 4 }
];

export const Equipos = [
  { id: 1, nombre: 'Real Madrid', presupuesto: 800000000, titulos: 35, estadio: 'Santiago Bernabéu', liga: 1 },
  { id: 2, nombre: 'FC Barcelona', presupuesto: 700000000, titulos: 30, estadio: 'Camp Nou', liga: 1 },
  { id: 3, nombre: 'Manchester City', presupuesto: 900000000, titulos: 7, estadio: 'Etihad Stadium', liga: 2 }
];

export const Jugadores = [
  { id: 1, nombre: 'Jugador 1', nacionalidad: 'España', posicion: 'Delantero', fecha_nacimiento: '1990-01-01', equipo: 1, valor_mercado: 100000000, partidos: 250, goles: 120, asistencias: 40 },
  { id: 2, nombre: 'Jugador 2', nacionalidad: 'Argentina', posicion: 'Centrocampista', fecha_nacimiento: '1992-05-05', equipo: 2, valor_mercado: 90000000, partidos: 210, goles: 60, asistencias: 80 }
];
