import * as equipoRepo from "../repositories/Equipo.repository.mjs";
import Equipo from "../models/equipo.model.mjs";
import supabase from "../config/supabase.mjs";

export async function getEquipos(req, res) {
  try {
    const equipos = await equipoRepo.getAllEquipos();
    res.json(equipos);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function getEquipo(req, res) {
  try {
    const equipo = await equipoRepo.getEquipoById(req.params.id);
    res.json(equipo);
  } catch (err) {
    res.status(404).json({ error: "Equipo no encontrado" });
  }
}

export async function createEquipo(req, res) {
  try {
    const {
      nombre,
      liga,
      presupuesto,
      titulos,
      estadio
    } = req.body;

    if (!nombre || !liga || presupuesto == null || titulos == null || !estadio) {
      return res.status(400).json({
        error: "Todos los campos son obligatorios"
      });
    }

    const { data, error } = await supabase
      .from("Equipos")
      .insert([
        {
          nombre,
          liga,
          presupuesto,
          titulos,
          estadio
        }
      ])
      .select();

    if (error) throw error;

    res.status(201).json(data[0]);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

export async function updateEquipo(req, res) {
  try {
    const {
      nombre,
      liga,
      presupuesto,
      titulos,
      estadio
    } = req.body;

    const { data, error } = await supabase
      .from("Equipos")
      .update({
        nombre,
        liga,
        presupuesto,
        titulos,
        estadio
      })
      .eq("id", req.params.id)
      .select();

    if (error) throw error;

    res.json(data[0]);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

export async function deleteEquipo(req, res) {
  try {
    await equipoRepo.deleteEquipo(req.params.id);
    res.json({ message: "Equipo eliminado correctamente" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

function validarEquipo(equipo) {
  if (!equipo.nombre || equipo.nombre.trim() === "") {
    throw new Error("El nombre es obligatorio");
  }
  if (equipo.puntos < 0) {
    throw new Error("Los puntos no pueden ser negativos");
  }
}

export async function valorMercadoPorEquipo(req, res) {
  try {
    const data = await equipoRepo.getValorMercadoPorEquipo();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

