import * as jugadorRepo from "../repositories/Jugador.repository.mjs";
import * as equipoRepo from "../repositories/Equipo.repository.mjs";
import Jugador from "../models/jugador.model.mjs";
import supabase from "../config/supabase.mjs";
export async function getJugadores(req, res) {
export async function getJugadores(req, res) {
  try {
    const jugadores = await jugadorRepo.getAllJugadores();
    res.json(jugadores);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function getJugador(req, res) {
  try {
    const jugador = await jugadorRepo.getJugadorById(req.params.id);
    res.json(jugador);
  } catch (err) {
    res.status(404).json({ error: "Jugador no encontrado" });
  }
}

export async function createJugador(req, res) {
  try {
    const {
      nombre,
      nacionalidad,
      posicion,
      fecha_nacimiento,
      equipo,
      valor_mercado,
      partidos,
      goles,
      asistencias
    } = req.body;

    if (
      !nombre || !nacionalidad || !posicion ||
      !fecha_nacimiento || !equipo ||
      valor_mercado == null || partidos == null ||
      goles == null || asistencias == null
    ) {
      return res.status(400).json({
        error: "Todos los campos son obligatorios"
      });
    }

    const { data, error } = await supabase
      .from("Jugadores")
      .insert([
        {
          nombre,
          nacionalidad,
          posicion,
          fecha_nacimiento,
          equipo,
          valor_mercado,
          partidos,
          goles,
          asistencias
        }
      ])
      .select();

    if (error) throw error;

    res.status(201).json(data[0]);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

export async function updateJugador(req, res) {
  try {
    const {
      nombre,
      nacionalidad,
      posicion,
      fecha_nacimiento,
      equipo,
      valor_mercado,
      partidos,
      goles,
      asistencias
    } = req.body;

    const { data, error } = await supabase
      .from("Jugadores")
      .update({
        nombre,
        nacionalidad,
        posicion,
        fecha_nacimiento,
        equipo,
        valor_mercado,
        partidos,
        goles,
        asistencias
      })
      .eq("id", req.params.id)
      .select();

    if (error) throw error;

    res.json(data[0]);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

export async function deleteJugador(req, res) {
  try {
    await jugadorRepo.deleteJugador(req.params.id);
    res.json({ message: "Jugador eliminado correctamente" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

function validarJugador(jugador) {
  if (!jugador.nombre || jugador.nombre.trim() === "") {
    throw new Error("El nombre es obligatorio");
  }
  if (jugador.goles < 0 || jugador.asistencias < 0) {
    throw new Error("Goles y asistencias no pueden ser negativos");
  }
}

export async function topGoleadores(req, res) {
  try {
    const data = await jugadorRepo.getTopGoleadores();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function topAsistencias(req, res) {
  try {
    const data = await jugadorRepo.getTopAsistencias();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function jugadoresPorEquipo(req, res) {
  try {
    const equipoId = Number(req.params.equipoId);

    if (isNaN(equipoId)) {
      return res.status(400).json({
        error: "El id de equipo debe ser un número"
      });
    }

    const { data, error } = await supabase
      .from("Jugadores")
      .select("*")
      .eq("equipo", equipoId);

    if (error) throw error;

    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
