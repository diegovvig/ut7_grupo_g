/*
  controllers/Liga.controller.mjs
  - Endpoints CRUD y consultas para las ligas
  - Usa el repositorio `Liga.repository.mjs` y Supabase para persistencia
*/
import * as ligaRepo from "../repositories/Liga.repository.mjs";
import Liga from "../models/Liga.model.mjs";
import supabase from "../config/supabase.mjs";

// GET /ligas -> devuelve lista de ligas (usa fixtures si BD vacía)
export async function getLigas(req, res) {
  try {
    const ligas = await ligaRepo.getAllLigas();
    res.json(ligas);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// GET /ligas/:id -> devuelve una liga por ID
export async function getLiga(req, res) {
  console.log('getLiga called with id:', req.params.id);
  try {
    const liga = await ligaRepo.getLigaById(req.params.id);
    if (!liga) {
      return res.status(404).json({ error: "Liga no encontrada" });
    }
    res.json(liga);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

// POST /ligas -> crear nueva liga (valida campos requeridos)
export async function createLiga(req, res) {
  try {
    const { nombre, pais, maximo_equipo_ganador } = req.body;

    if (!nombre || !pais || !maximo_equipo_ganador) {
      return res.status(400).json({
        error: "nombre, pais y maximo_equipo_ganador son obligatorios"
      });
    }

    const { data, error } = await supabase
      .from("Ligas")
      .insert([
        { nombre, pais, maximo_equipo_ganador }
      ])
      .select();

    if (error) throw error;

    res.status(201).json(data[0]);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

// PUT /ligas/:id -> actualizar liga (valida campos)
export async function updateLiga(req, res) {
  try {
    const { nombre, pais, maximo_equipo_ganador } = req.body;

    if (!nombre || !pais || !maximo_equipo_ganador) {
      return res.status(400).json({
        error: "nombre, pais y maximo_equipo_ganador son obligatorios"
      });
    }

    const { data, error } = await supabase
      .from("Ligas")
      .update({
        nombre,
        pais,
        maximo_equipo_ganador
      })
      .eq("id", req.params.id)
      .select();

    if (error) throw error;

    res.json(data[0]);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

// DELETE /ligas/:id -> elimina una liga
export async function deleteLiga(req, res) {
  try {
    await ligaRepo.deleteLiga(req.params.id);
    res.json({ message: "Liga eliminada" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}

// Validación simple de entidad liga (utilidad interna)
function validarLiga(liga) {
  if (!liga.nombre || liga.nombre.trim() === "") {
    throw new Error("El nombre es obligatorio");
  }
}

// GET /stats/equipos-por-liga -> devuelve conteo de equipos por liga
export async function equiposPorLiga(req, res) {
  try {
    const data = await ligaRepo.getEquiposPorLiga();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
