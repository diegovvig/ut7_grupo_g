import express from "express";
import {
  getEquipos,
  getEquipo,
  createEquipo,
  updateEquipo,
  deleteEquipo,
  valorMercadoPorEquipo
} from "../controllers/Equipo.controller.mjs";

const router = express.Router();

router.get("/", getEquipos);
router.get("/:id", getEquipo);
router.post("/", createEquipo);
router.put("/:id", updateEquipo);
router.delete("/:id", deleteEquipo);
router.get("/stats/valor-mercado", valorMercadoPorEquipo);

export default router;