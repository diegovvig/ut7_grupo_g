/*
  repositories/Liga.repository.mjs
  - Operaciones de acceso a datos para la entidad `Ligas`
  - Incluye fallback a `fixtures` cuando la tabla está vacía (útil en desarrollo)
*/
import supabase from "../config/supabase.mjs";
import { Ligas as fixtureLigas } from "../data/fixtures.mjs";

// Obtener todas las ligas; si la tabla está vacía devolver las fixtures
export async function getAllLigas() {
  const { data, error } = await supabase
    .from("Ligas")
    .select("*");
  console.log('DEBUG getAllLigas ->', { dataLength: Array.isArray(data) ? data.length : null, error: error ? error.message || error : null });
  if (error) throw error;

  if (!data || (Array.isArray(data) && data.length === 0)) {
    return fixtureLigas;
  }
  return data;
}

// Obtener una liga por ID
export async function getLigaById(id) {
  console.log('getLigaById called with id:', id);
  const { data, error } = await supabase
    .from("Ligas")
    .select("*")
    .eq("id", id)
    .single();
  console.log('Supabase result:', { data, error });
  if (error) {
    if (error.code === 'PGRST116') { // No rows returned
      // Check in fixtures
      const fixture = fixtureLigas.find(l => l.id == id);
      console.log('Fixture found:', fixture);
      return fixture || null;
    }
    throw error;
  }
  return data;
}

// Insertar una nueva liga
export async function createLiga(liga) {
  const { data, error } = await supabase
    .from("Ligas")
    .insert([liga])
    .select();

  if (error) throw error;
  return data[0];
}

// Borrar liga por id
export async function deleteLiga(id) {
  const { error } = await supabase
    .from("Ligas")
    .delete()
    .eq("id", id);
  if (error) throw error;
}

// Contar equipos por liga: devuelve un objeto { ligaId: cantidad }
export async function getEquiposPorLiga() {
  const { data, error } = await supabase
    .from("Equipos")
    .select("liga");

  if (error) throw error;

  const resultado = {};
  data.forEach(e => {
    resultado[e.liga] = (resultado[e.liga] || 0) + 1;
  });

  return resultado;
}

