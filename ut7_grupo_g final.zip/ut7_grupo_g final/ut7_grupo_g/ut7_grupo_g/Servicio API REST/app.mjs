import express from "express";
import 'dotenv/config';
import equipoRoutes from "./routes/Equipo.routes.mjs";
import jugadorRoutes from "./routes/Jugador.routes.mjs";
import ligaRoutes from "./routes/Liga.routes.mjs";
import supabase from "./config/supabase.mjs";

const app = express();

app.use(express.json());

console.log('Mounting routes');
app.use("/api/equipos", equipoRoutes);
app.use("/api/jugadores", jugadorRoutes);
app.use("/api/ligas", ligaRoutes);

app.use("/equipos", equipoRoutes);
app.use("/jugadores", jugadorRoutes);
app.use("/ligas", ligaRoutes);
console.log('Routes mounted');

app.listen(3000, () => {
  console.log("API REST escuchando en puerto 3000");
});
