export default class Liga {
  constructor({ id, nombre, pais, maximo_equipo_ganador }) {
    this.id = id;
    this.nombre = nombre;
    this.pais = pais;
    this.maximo_equipo_ganador = maximo_equipo_ganador;
  }
}
